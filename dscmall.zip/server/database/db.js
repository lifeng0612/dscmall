let mysql = require('mysql');
let connection = mysql.createConnection({
    host: 'localhost', //域名或ip地址
    user: 'root', //mysql数据库的用户名
    password: '', //mysql数据库密码
    database: 'shop' //要连接数据库的名字
});

// const userSql = "SELECT * FROM hg_users WHERE is_show = 1"

// connection.query(userSql, (err, data) => {
//     if (!err) {
//         console.log(data);
//     }
// })


//分装查询方法，给不同的SQL查询对应的数据
function requestQuery(sql, sqlAll) {
    return new Promise((resolve, reject) => {
        connection.query(sql, sqlAll, (err, data) => {
            if (err) {
                reject(err)
            } else {
                resolve(data)
            }
        })
    })
}

module.exports = {
    connection,
    requestQuery,
}