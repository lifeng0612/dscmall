//引入db模块
const { requestQuery, connection } = require("../database/db")

//格式化时间模块
const moment = require("moment");
//加密模块
const bcrypt = require('bcryptjs');
const salt = bcrypt.genSaltSync(10);
//引入token模块
const JWT = require("../token");
//随机生成字符串
const random = require('string-random');
//随机svg验证码
var svgCaptcha = require('svg-captcha');
//定义一个变量来临时存储手机号
var temPhone = null;
//定义一个变量来临时存储验证码
var tempCode = null;
//定义一个变量来临时svg验证码
var tempCaptcha = null;
//短信验证
const { iHuyi } = require("./HUQIAN");
//用户列表
exports.UserList = async(req, res) => {
    const userSql = "SELECT * FROM hg_users WHERE is_show = 1"
    const userList = await requestQuery(userSql)
    res.json({
        data: userList
    })
}

//用户注册
exports.UserRegister = (req, res) => {
    console.log(req.body);
    let user_name = req.body.user_name
    let login_password = req.body.login_password
    let phone = req.body.phone

    let sql_name = "SELECT user_name FROM hg_users WHERE user_name=? AND is_show = 1 "
        //获取当前时间 
    let nowDate = moment().format("YYYY-MM--DD HH:mm:ss")
    console.log(nowDate);
    connection.query(sql_name, user_name, (err, result_name) => {
        if (err) {
            return res.json({
                msg: "用户注册失败",
                status: 1001,
                data: err
            })
        }
        //需求如果用户存在不能注册，用户名不存在，但是手机号存在也不能注册
        //如果result_name为空，说明该用户不存在，说明用户名可以使用
        if (result_name == "") {
            let sql_phone = "SELECT phone from hg_users WHERE phone=? AND is_show=1"
            connection.query(sql_phone, phone, (err, result_phone) => {
                if (err) {
                    return res.json({
                        msg: "用户注册失败",
                        status: 1002,
                        data: err
                    })
                }
                //result_phone为空，说明该手机号可用
                if (result_phone == "") {
                    let sql_register = `INSERT INTO hg_users SET user_name=?,login_password=?,phone=?,is_show=1,create_time="${nowDate}"`
                    const hashpassword = bcrypt.hashSync(login_password, salt)
                    connection.query(sql_register, [user_name, hashpassword, phone], (err, result) => {
                        if (err) {
                            return res.json({
                                msg: "用户注册失败",
                                status: 1003,
                                data: err
                            })
                        }
                        if (result.affectedRows == 1) {
                            return res.json({
                                msg: "注册成功,可以去登陆了",
                                status: 200,
                                data: result
                            })
                        } else {
                            return res.json({
                                msg: "用户注册失败",
                                status: 1004,
                                data: err
                            })
                        }
                    })
                } else {
                    return res.json({
                        msg: "改手机号已存在,请更换手机号注册",
                        status: 5000
                    })
                }
            })
        } else {
            return res.json({
                msg: "该用户名已存在,请更换用户名注册",
                status: 5001
            })
        }
    })
}


//用户登录
exports.UserLogin = async(req, res) => {
    let user_name = req.body.user_name;
    // console.log(req.body.captcha);
    const captcha = req.body.captcha.toLowerCase();
    if (captcha != tempCaptcha) {
        return res.json({
            status: 4007,
            msg: "验证码不正确"
        })
    }
    let sql = `SELECT user_name,login_password from hg_users WHERE user_name=? AND is_show=1`
    connection.query(sql, [user_name], (err, result) => {
        if (err) {
            return res.json({
                msg: "数据库查询失败",
                status: 500
            })
        }
        if (result == "") {
            return res.json({
                msg: "该用户不存在,快去注册一个吧",
                status: 1005
            })
        } else {
            const login_password = bcrypt.compareSync(req.body.login_password, result[0].login_password)
            if (login_password !== true) {
                return res.json({
                    msg: "密码输入错误,请重新输入",
                    status: 500
                })
            } else {
                let token = JWT.createToken({
                    login: true,
                    user_name: user_name
                })
                JWT.verifyToken(token)
                return res.json({
                    msg: "登陆成功",
                    data: result,
                    status: 200,
                    token: token
                })
            }
        }
    })
}

//手机号短信验证
exports.GetIdentifyingCode = async(req, res) => {
    // console.log(req.body);
    var phone = req.body.phone;
    // var captcha = req.body.captcha
    temPhone = req.body.phone; //临时手机号赋值
    //随机生成六位验证码
    var identCode = ("0" + Math.floor(Math.random() * 999999)).slice(-6)
    console.log(identCode);
    tempCode = identCode
    let MessageContent = "您的验证码是：" + identCode + "。请不要把验证码泄露给其他人。"
    iHuyi.send(phone, MessageContent, (err, smsId) => {
        // if (captcha != tempCaptcha) {
        //     return res.json({
        //         status: 4007,
        //         mag: "验证码不正确"
        //     })
        // } else
        if (err) {
            res.json({
                msg: "验证码发送成功",
                status: 200,
                data: identCode
            })
            console.log(err.message);
        } else {
            console.log("SMS sent, and smsId is " + smsId);
        }
    });

}

//短信登录
exports.PhoneLogin = async(req, res) => {
    console.log(req.body.phone);
    console.log(req.body.code);
    var phone = req.body.phone
    var code = req.body.code
    var captcha = req.body.captcha.toLowerCase()
    if (captcha != tempCaptcha) {
        return res.json({
            status: 4007,
            mag: "验证码不正确"
        })
    } else if (phone != temPhone) {
        return res.json({
            status: 4006,
            mag: "手机号不正确"
        })
    } else if (code != tempCode) {
        return res.json({
            status: 4005,
            mag: "手机号验证码不正确"
        })
    } else {
        //判断手机号是否在数据库内
        const sql_phone = "SELECT * FROM hg_users WHERE phone=? AND is_show=1";
        const phone_result = await requestQuery(sql_phone, phone)
            // console.log(phone_result);
        if (phone_result.length == 0) {
            const user_name = "hg_" + random(10)
            let time = moment(new Date()).format("YYYY-MM--DD HH:mm:ss")
            const sql_register = `INSERT INTO hg_users (user_name,phone,is_show,create_time) VALUES ("${user_name}",${phone},"1","${time}")`
            const phoneRegsult = await requestQuery(sql_register);
            const result = await requestQuery(sql_phone, phone);
            if (phoneRegsult.affectedRows == 1) {
                let token = JWT.createToken({
                    login: true,
                    phone: result[0].phone
                })
                return res.json({
                    status: 200,
                    msg: "登陆成功",
                    data: result,
                    token: token
                })
            } else {
                return res.json({
                    status: 500,
                    msg: "服务器错误"
                })
            }
        } else { //手机号存在
            let token = JWT.createToken({
                login: true,
                phone: phone
            })
            return res.json({
                status: 200,
                msg: "登陆成功",
                data: phone_result,
                token: token
            })
        }
    }
}

//svg验证码
exports.SvgCaptcha = (req, res) => {
    var captcha = svgCaptcha.create({
        size: 4, // 验证码长度
        ignoreChars: '0o1i', // 验证码字符中排除 0o1i
        noise: 3, // 干扰线条的数量
        color: true, // 验证码的字符是否有颜色，默认没有，如果设定了背景，则默认有
        background: '#efefef', // 验证码图片背景颜色
    });
    tempCaptcha = captcha.text.toLowerCase();
    console.log(captcha.text);

    res.type('svg');
    res.status(200).send(captcha.data);
}