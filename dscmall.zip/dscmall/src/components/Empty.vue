<!--  -->
<template>
  <div class="empty">
    <i
      href="javascript:;"
      class="iconfont icon-jiantou3"
      @click="history"
    ></i>
    <Loading></Loading>
    <div class="emptTtitle">
      <h2>没有更多数据了!</h2>
    </div>
    <div class="brack" @click="changeempty">
      <button type="button">首页</button>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Loading from "./Loading";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    Loading,
  },
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    changeempty() {
      this.$router.push("/home/index");
    },
    history(){
      window.history.back();
    }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.empty {
  i {
    display: block;
    // width: 100%;
    z-index: 10001;
    position: absolute;
    top: 2rem;
    left: 2rem;
  }
  .emptTtitle {
    width: 100%;
    height: 100%;
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    right: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 10000;
  }
  h2 {
    z-index: 10000;
    color: #000;
    width: 100%;
    text-align: center;
    color: #999;
    top: 50%;
  }
  .brack {
    position: fixed;
    z-index: 10000;
    bottom: 5%;
    right: 20%;
    button {
      width: 8rem;
      height: 4rem;
      background-color: red;
      border-radius: 10px;
      color: #fff;
      font-size: 1.8rem;
      z-index: 10000;
    }
  }
}
</style>