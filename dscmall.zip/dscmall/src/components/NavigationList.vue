<!--  -->
<template>
<div class="NavigationList">
    <ul>
        <li :class="{cative: cative}" @click="change">
            <span>综合</span>
            <i class="iconfont icon-xiala" v-if="active"></i>
            <i class="iconfont icon-xiala2" v-if="!active"></i>
        </li>
        <li :class="{activesort: activesort}" @click="changesort">
            <span>新品</span>
        </li>
        <li :class="{activesorts: activesorts}" @click="changesorts">
            <span>销量</span>
        </li>
        <li :class="{oactive: oactive}" @click="changeoders">
            <span>价格</span>
            <i class="iconfont icon-xiala" v-if="activeoders"></i>
            <i class="iconfont icon-xiala2" v-if="!activeoders"></i>
        </li>
        <li @click="show">
            <i class="iconfont icon-shaixuan"></i>
            <span>筛选</span>
        </li>
    </ul>
</div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
//import引入的组件需要注入到对象中才能使用
components: {},
data() {
//这里存放数据
return {
    cative:true,
    active:true,
    orders:["desc","asc"],
    order:"desc",
    activesort:false,
    activesorts:false,
    activeoders:false,
    oactive:false,
    sort:"last_update",
    sorts:"sales_volume",
    maskshow:false
};
},
//监听属性 类似于data概念
computed: {},
//监控data中的数据变化
watch: {
   
},
//方法集合
methods: {
    change(){
        this.oactive = false;
        this.cative = true
        this.active = !this.active;
        this.activesort = false;
        this.activesorts = false;
        this.activeoders = false;
        if(this.active){
            this.order = "desc"
        }else{
            this.order = "asc"
        }
        this.$emit("toparent",this.order)
    },
    changesort(){
        this.oactive = false;
        this.cative = false;
        this.active = false;
        this.activesort = !this.activesort;
        this.activesorts = false;
        this.activeoders = false;
        if(this.activesort){
            this.sort = "last_update"
        }else {
            this.sort = "goods_id"
        }
        this.$emit("toparentsort",this.sort)
    },
    changesorts(){
        this.oactive = false;
        this.cative = false;
        this.active = false;
        this.activesort = false;
        this.activeoders = false;
         this.activesorts = !this.activesorts;
        if(this.activesorts){
            this.sorts = "sales_volume"
        }else{
            this.sorts = "goods_id"
        }
        this.$emit("toparentsorts",this.sorts)
    },
    changeoders(){
        this.oactive = true;
        this.cative = false;
        this.active = false;
        this.activesort = false;
        this.activesorts = false;
        this.activeoders = !this.activeoders;
        if(this.activeoders){
            this.order = "desc"
        }else{
            this.order = "asc"
        }
        this.$emit("toparentoders",this.order)
    },
    show(){
        this.maskshow = true;
        this.$emit("toparentmask",this.maskshow)
        // console.log(this.maskshow);
    }
},
beforeCreate() {}, //生命周期 - 创建之前
//生命周期 - 创建完成（可以访问当前this实例）
created() {

},
beforeMount() {}, //生命周期 - 挂载之前
//生命周期 - 挂载完成（可以访问DOM元素）
mounted() {

},
beforeUpdate() {}, //生命周期 - 更新之前
updated() {}, //生命周期 - 更新之后
beforeDestroy() {}, //生命周期 - 销毁之前
destroyed() {}, //生命周期 - 销毁完成
activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
}
</script>
<style lang="less">
    .NavigationList{
        margin-top: 5rem;
        width: 100%;
        background-color: #fff;
        height: 3.5rem;
        line-height: 3.5rem;
        border-bottom: 1px solid #f1f1f1;
        ul{
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: space-between;
            li{
                width: 20%;
                text-align: center;
               display: flex;
               justify-content: center;
               i{
                   font-size: 1.6rem;
                   margin-left: .1rem;
                   margin-top: 1rem;
                   &:first-child{
                       margin-right: .1rem;
                       margin-left: 0;
                   }
               }
            }
            .cative{
                span{
                   color: red;
               }
               i{
                   color: red;
               }
            }
            
            .activesort{
               span{
                   color: red;
               }
               i{
                   color: red;
               }
            }
            .activesorts{
               span{
                   color: red;
               }
               i{
                   color: red;
               }
            }
            .oactive{
                span{
                   color: red;
               }
               i{
                   color: red;
               }
            }
        }
    }
</style>