<!--  -->
<template>
  <div class="lists">
    <ul>
      <li v-for="(listdata,goods_id,index) in listdatas" :key="index">
        <router-link :to="'/goodsdetail/'+ listdata.goods_id">
          <img :src="listdata.goods_thumb" alt="" v-if="listdata.goods_thumb"/>
        <img :src="listdata.img" alt="" class="active" v-if="listdata.img"/>
        <div class="lists-title">
          <div v-if="listdata.title">{{ listdata.title }}</div>
          <div>{{ listdata.goods_name }}</div>
        </div>
        <div class="lists-price">
          <span v-if="listdata.shop_price_formated">{{ listdata.shop_price_formated }}</span>
          <img :src="listdata.user_picture" alt="" v-if="listdata.user_picture">
          <em v-if="listdata.user_name">{{listdata.user_name}}</em>
          <p v-if="listdata.dis_browse_num">
            <i class="iconfont icon-xianshi"></i>
          <em>{{listdata.dis_browse_num}}</em>
          </p>
        </div>
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    listdatas: Array,
  },
  data() {
    //这里存放数据
    return {
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {

  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.lists {
  width: 100%;
  margin-left: 10px;
  margin-right: 10px;
  width: calc(100% - 20px);
  ul {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    li {
      width: 48%;
      background-color: #fff;
      margin-top: 1rem;
      border-radius: 10px;
      img {
        width: 100%;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
      }
      .active{
        width: 100%;
        height: 20rem;
      }
      .lists-title {
        box-sizing: border-box;
        width: 100%;
        height: 6.5rem;
        padding: 1.5rem;
        div {
          font-size: 1.5rem;
          color: #000;
          line-height: 2.1rem;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      }
      .lists-price {
        width: 100%;
        margin-bottom: 8px;
        box-sizing: border-box;
        padding-left: 10px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        span {
          font-size: 15px;
          font-weight: 700;
          color: rgb(242, 14, 40);
        }
        img{
          width: 10%;
          width: 2rem;
          height: 2rem;
          border-radius: 50%;
        }
        em{
          width: 61%;
          padding-left: 4px;
          font-style: normal;
          text-align: left;
        }
       p{
         display: flex;
         align-items: center;
          em{
          font-style: normal;
          margin-right: 1rem;
          margin-left: 0.2rem;
        }
       }
      }
    }
  }
}
</style>