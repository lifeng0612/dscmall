<!--  -->
<template>
  <div class="Quicknavigation">
    <div :class="show ? 'quick common-nav' : 'quick'">
      <div class="gation active">
        <ul>
          <li>
            <router-link to="/home">
              <i class="iconfont icon-shouye"></i>
              <p>首页</p>
            </router-link>
          </li>
          <li>
            <router-link to="/search">
              <i class="iconfont icon-sousuo2"></i>
              <p>搜索</p>
            </router-link>
          </li>
          <li>
            <router-link to="/category">
              <i class="iconfont icon-fenlei"></i>
              <p>分类</p>
            </router-link>
          </li>
          <li>
            <router-link to="/cart">
              <i class="iconfont icon-gouwuche1"></i>
              <p>购物车</p>
            </router-link>
          </li>
          <li>
            <router-link to="/mine">
              <i class="iconfont icon-profile"></i>
              <p>个人中心</p>
            </router-link>
          </li>
        </ul>
        <div class="nav-ion" @click="changshow">快速导航</div>
      </div>
    </div>
    <div class="gation-show" v-if="show" @click="changehide"></div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      show: false,
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    changshow() {
      this.show = !this.show;
    },
    changehide(){
      this.show = false;
    }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.Quicknavigation {
  width: 100%;
  height: 100%;
  .quick {
    position: fixed;
    right: 1rem;
    bottom: 12rem;
    width: 4.5rem;
    height: 28rem;
    overflow: hidden;
    z-index: 100;
    .gation {
      position: absolute;
      right: 0rem;
      bottom: -1rem;
      width: 4.5rem;
      height: 0;
      background: rgba(255, 255, 255, 0.8);
      border-radius: 2.25rem;
      transition: all 1s;
      z-index: 100;
      ul {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-top: 0.5rem;
        li {
          width: 100%;
          height: 4.5rem;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          text-align: center;
          margin-bottom: 0.3rem;
          i {
            font-size: 1.6rem;
          }
          p {
            width: 100%;
            font-size: 1.2rem;
            margin-top: 0.3rem;
          }
        }
      }
      .nav-ion {
        width: 4.5rem;
        height: 4.5rem;
        border-radius: 50%;
        background-color: #f92028;
        color: #fff;
        box-sizing: border-box;
        font-size: 1.2rem;
        padding-left: 0.2rem;
        display: flex;
        align-items: center;
        letter-spacing: 4px;
        text-align: center;
        position: fixed;
        bottom: 10rem;
        right: 1rem;
      }
    }
  }
  .common-nav {
    transition: all 0.5s;
    .active {
      height: 28rem;
      transition: all 0.5s;
    }
  }
  .gation-show {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.3);
    z-index: 99;
  }
}
</style>