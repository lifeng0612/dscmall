<!--  -->
<template>
  <div class="ContentTypes">
    <div class="secondary">
      <ul>
        <li v-for="(getdatalist, index) in getdatalists" :key="index">
          <div class="sec-img">
            <img :src="getdatalist.touch_icon" alt="" />
          </div>
          <p>{{ getdatalist.cat_name }}</p>
        </li>
      </ul>
    </div>
    <div class="brand">
      <div class="title">品牌精选</div>
      <ul>
        <li v-for="(getdatafy, index) in getdatafys" :key="index">
          <div class="bra-img">
            <img :src="getdatafy.brand_logo" alt="" />
          </div>
          <p>{{ getdatafy.brand_name }}</p>
        </li>
      </ul>
    </div>
    <div>
      <List></List>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import List from "./List"
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    List
  },
  props: {
    getdatalists: Array,
    getdatafys: Array,
  },
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.ContentTypes {
  width: calc(100% - 20px);
  margin-left: 10px;
  margin-right: 10px;
  .secondary {
    padding: 1.5rem 1rem;
    background-color: #fff;
    border-radius: 10px;
    overflow: hidden;
    ul {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      li {
        width: 20%;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 1rem;
        .sec-img {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 7.5rem;
          img {
            width: 100%;
            height: auto;
          }
        }
        p {
          margin-top: 0.3rem;
          text-align: center;
        }
      }
    }
  }
  .brand {
    padding: 1.5rem 1rem;
    background-color: #fff;
    border-radius: 10px;
    overflow: hidden;
    margin-top: 1rem;
    margin-bottom: 1rem;
    .title {
      font-size: 1.5rem;
      color: #000;
      padding: 0.2rem 1rem 1rem;
    }
    ul {
      display: flex;
      flex-wrap: wrap;
      li {
        width: 25%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        margin-bottom: 1rem;
        .bra-img {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 5.5rem;
          img {
            width: 100%;
          }
        }
        p{
            font-size: 1.2rem;
        }
      }
    }
  }
}
</style>