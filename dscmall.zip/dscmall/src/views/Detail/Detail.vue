<!--  -->
<template>
  <div
    class="detail"
    v-infinite-scroll="loadMore"
    infinite-scroll-disabled="loading"
  >
    <Loading v-if="!loadingshow"></Loading>
    <!-- 头部 -->
    <div :class="{ detail_top: true, detail_tops: topbgc }" ref="header">
      <div class="top-back" onclick="window.history.back()">
        <i
          :class="
            !topbgc
              ? 'iconfont icon-jiantou3 top_backs'
              : 'iconfont icon-jiantou3'
          "
        ></i>
      </div>
      <div :class="{ top_titel: true, top_bgc: topbgc }">
        <ul>
          <li :class="top ? 'title-border' : ''" @click="topshow">商品</li>
          <li :class="topx ? 'title-border' : ''" @click="topshows">详情</li>
          <li :class="topleave ? 'title-border' : ''" @click="topshowleave">
            推荐
          </li>
        </ul>
      </div>
      <div class="top-share top-back" @click="shareshow">
        <i
          :class="
            !topbgc
              ? 'iconfont icon-fenxiang top_backs'
              : 'iconfont icon-fenxiang'
          "
        ></i>
      </div>
    </div>
    <!-- 分享 -->
    <div class="share_mask" v-if="showshare" @click="shareshowmask"></div>
    <div :class="!showshare ? 'share_info share_info_shk' : 'share_info'">
      <div class="share">
        <div class="share_thum" v-if="thumhide" @click="weixinmask">
          <div class="iconfont icon-weixin"></div>
          <div class="share_title">发送给好友</div>
        </div>
        <div class="share_thum" @click="sharePosterFn">
          <div class="iconfont icon-shengchenghaibao"></div>
          <div class="share_title">生成海报</div>
        </div>
      </div>
    </div>
    <!-- 发送给好友 -->
    <ShareInfo @shareImginfo="shareImginfo" :weixinImg="weixinImg"></ShareInfo>
    <!-- 生成海报 -->
    <SharePoster
      @closeSharePoster="closeSharePoster"
      :porsters="porsters"
      :posterDatas="posterDatas"
    ></SharePoster>
    <!-- 轮播 -->
    <div class="swiper swipers" @click="swipersm">
      <mt-swipe :auto="4000">
        <mt-swipe-item
          v-for="(detaildate, index) in detaildates.gallery_list"
          :key="index"
        >
          <img :src="detaildate.img_url" alt="" />
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <!-- 全屏轮播 -->
    <div class="swiper_big" @click="swiperBigs" v-if="swiperBig">
      <div class="swiper swipers swipers_big">
        <mt-swipe :auto="0" :show-indicators="false" :continuous="continuous">
          <mt-swipe-item
            v-for="(detaildate, index) in detaildates.gallery_list"
            :key="index"
          >
            <img :src="detaildate.img_url" alt="" />
          </mt-swipe-item>
        </mt-swipe>
      </div>
    </div>
    <!-- 价钱 -->
    <div class="goods_price">
      <div class="price">{{ detaildates.shop_price }}</div>
      <div class="old_price">{{ detaildates.market_price }}</div>
    </div>
    <!-- 标题 -->
    <div class="detail_goods_title">
      {{ detaildates.goods_name }}
    </div>
    <!-- 销量--库存--地点 -->
    <div class="detail-location">
      <div class="sales">累计销量 {{ detaildates.sales_volume }}</div>
      <div class="repertory">库存{{ detaildates.goods_number }}</div>
      <div class="site">
        {{ detaildatebasics.province_name }}&nbsp;{{
          detaildatebasics.city_name
        }}
      </div>
    </div>
    <!-- 积分--服务 -->
    <div class="detail-inte">
      <div class="give">
        赠送积分：<span>{{ detaildates.use_give_integral }}&nbsp;积分</span>
      </div>
      <div class="serve">
        服务：<span>正品保证 七天无理由退换 闪速配送</span>
      </div>
    </div>
    <!-- 配送--运费 -->
    <div class="detail-inte" @click="addresshow">
      <div class="give">
        送至：<span>{{ province }}-{{ city }}-{{ country }}</span>
        <i class="iconfont icon-jiantou2"></i>
      </div>
      <div class="serve">
        运费：<span>{{ detaildates.formated_goods_rate }}</span>
      </div>
    </div>
    <!-- 地址弹窗 -->
    <div class="address">
      <mt-popup v-model="popupVisible" position="bottom">
        <div class="addres">
          <div class="addres_titel">
            <span>所在地区</span>
            <i class="iconfont icon-chahao" @click="addreshides"></i>
          </div>
          <mt-picker
            :slots="slots"
            :visibleItemCount="visibleItemCount"
            @change="onValuesChange"
          ></mt-picker>
        </div>
      </mt-popup>
    </div>
    <!-- 已选 -->
    <div class="goods_select" @click="showmask">
      <div class="setect">
        已选：<span>{{ buyNum }}个</span>
      </div>
      <i class="iconfont icon-jiantou2"></i>
    </div>
    <!-- 讨论圈-->
    <div class="goods_select">
      <div class="setect">网友讨论圈</div>
      <i class="iconfont icon-jiantou2"></i>
    </div>
    <!-- 商品数量弹窗 -->
    <div class="num-mask" v-if="!showmasks" @click="hidemask"></div>
    <div class="godds_mask" :class="{ godds_masks: showmasks }">
      <div class="attr-goods-header">
        <div class="goods_img">
          <img :src="detaildates.goods_thumb" alt="" />
        </div>
        <div class="goods_info">
          <div class="info_goods_titel">{{ detaildates.goods_name }}</div>
          <div class="info_price">{{ detaildates.shop_price }}</div>
          <div class="info_volum">库存：{{ detaildates.goods_number }}</div>
          <i class="iconfont icon-chahao" @click="hidemask"></i>
        </div>
        <div class="goods_number">
          <div class="number">数量</div>
          <div class="stepper">
            <button
              type="button"
              @click="subtract"
              :class="{ disableds: disabled }"
            >
              -
            </button>
            <input type="number" v-model="buyNum" />
            <button type="button" @click="plus">+</button>
          </div>
        </div>
        <div class="goods_footer">
          <div class="foobuy">立即购买</div>
          <div class="foocart" @click="addshow">加入购物车</div>
        </div>
      </div>
    </div>
    <!-- 商品详情tabs -->
    <div class="goods_tabs" ref="goods">
      <mt-navbar class="page-part" v-model="selected">
        <mt-tab-item id="tab1">商品详情</mt-tab-item>
        <mt-tab-item id="tab2">规格参数</mt-tab-item>
      </mt-navbar>
      <mt-tab-container v-model="selected">
        <mt-tab-container-item id="tab1">
          <div class="goods_page" v-html="detaildates.goods_desc"></div>
        </mt-tab-container-item>
        <mt-tab-container-item id="tab2">
          <div class="standard">
            <table>
              <tr>
                <td>商品编号</td>
                <td>{{ detaildates.goods_sn }}</td>
              </tr>
              <tr>
                <th colspan="2">主体</th>
              </tr>
              <tr>
                <td>品牌</td>
                <td></td>
              </tr>
              <tr>
                <td>商品重量</td>
                <td>{{ detaildates.goods_weight }}kg</td>
              </tr>
              <tr>
                <td>上架时间</td>
                <td>{{ detaildates.add_time_format }}</td>
              </tr>
              <tr>
                <th colspan="2">产品规则</th>
              </tr>
              <tr
                v-for="(parame, index) in detaildates.attr_parameter"
                :key="index"
              >
                <td>{{ parame.attr_name }}</td>
                <td>{{ parame.attr_value }}</td>
              </tr>
            </table>
          </div>
        </mt-tab-container-item>
      </mt-tab-container>
    </div>
    <DetailList :detaillists="detaillists"></DetailList>
    <!-- 底部 -->
    <div class="footer">
      <div class="footer_service">
        <i class="iconfont icon-xiaoxi"></i>
        <span>客服</span>
      </div>
      <div class="footer_collect">
        <i class="iconfont icon-shoucang1"></i>
        <span>收藏</span>
      </div>
      <div class="footer_cart" @click="carts">
        <i class="iconfont icon-gouwuche"></i>
        <span>购物车</span>
        <div class="cart_info">{{ locationdata }}</div>
        <transition
          name="em"
          @before-enter="beforeEnter"
          @enter="enter"
          @after-enter="afterEnter"
        >
          <em v-if="emshow">+{{ buyNum }}</em>
        </transition>
      </div>
      <div class="footer_gocart" @click="addshow">加入购物车</div>
      <div class="footer_gobuy">立即购买</div>
    </div>
    <transition name="masker">
      <div class="detail_fotter_mask" v-if="emshow">
        <span>&#10003;</span>
        <i>已加入购物车</i>
      </div>
    </transition>
    <QuickNavigation></QuickNavigation>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import citydatas from "@/assets/Json/City.json";
import Loading from "@/components/Loading";
import DetailList from "./components/DetailList";
import { isweixin } from "@/utils/index.js";
import ShareInfo from "./components/ShareInfo";
import SharePoster from "./components/SharePoster";
import QuickNavigation from "@/components/QuickNavigation";
// console.log(isweixin());
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    Loading,
    DetailList,
    ShareInfo,
    SharePoster,
    QuickNavigation
  },
  data() {
    //这里存放数据
    return {
      porsters: false,
      weixinImg: false,
      thumhide: true,
      showshare: false,
      swiperBig: false,
      continuous: false,
      emshow: false,
      gotop: false,
      topbgc: true,
      top: true,
      topx: false,
      topleave: false,
      goods_id: 1153,
      showmasks: true,
      buyNum: 1,
      disabled: false,
      selected: "tab1",
      popupVisible: false,
      visibleItemCount: 6,
      province: "选择省",
      city: "选择市",
      country: "市/区",
      page: 1,
      size: 10,
      slots: [
        {
          flex: 1,
          values: Object.keys(citydatas),
          className: "slot1",
          textAlign: "center",
          defaultIndex: 0,
        },
        {
          divider: true,
          content: "-",
          className: "slot2",
        },
        {
          flex: 1,
          values: [],
          className: "slot3",
          textAlign: "center",
        },
        {
          divider: true,
          content: "-",
          className: "slot4",
        },
        {
          flex: 1,
          values: [],
          className: "slot5",
          textAlign: "center",
        },
      ],
    };
  },
  //监听属性 类似于data概念
  computed: {
    detaildates() {
      return this.$store.state.detaildate;
    },
    detaildatebasics() {
      return this.$store.state.detaildatebasic;
    },
    loadingshow() {
      return this.$store.state.loading;
    },
    detaillists() {
      return this.$store.state.detailLists;
    },
    dataprams() {
      return this.$route.params;
    },
    posterDatas() {
      return this.$store.state.posterDatas;
    },
    locationdata() {
      let count = 0;
      this.$store.state.cartDatas.map((item) => {
        count += item.valus;
      });
      return count;
    },
  },
  //监控data中的数据变化
  watch: {
    buyNum() {
      if (this.buyNum >= this.detaildates.goods_number) {
        this.buyNum = this.detaildates.goods_number;
      }
      if (this.buyNum <= 1) {
        this.buyNum = 1;
      }
    },
    dataprams: function () {
      location.reload(true);
    },
  },
  //方法集合
  methods: {
    reqdetailList() {
      let params = {
        url: "/goods/goodsguess",
        params: {
          page: this.page,
          size: this.size,
        },
        type: "post",
      };
      this.$store.dispatch("actChangedetailList", params);
    },
    reqdetails() {
      let params = {
        url: "/goods/show",
        params: {
          goods_id: this.goods_id,
        },
        type: "post",
      };
      this.$store.dispatch("actChangedetail", params);
    },
    showmask() {
      this.showmasks = false;
    },
    hidemask() {
      this.showmasks = true;
    },
    subtract() {
      if (this.buyNum == 1) {
        this.disabled = true;
        this.buyNum = 1;
      }
      if (this.buyNum > 1) {
        this.buyNum--;
      }
    },
    plus() {
      this.disabled = false;
      this.buyNum++;
    },
    addresshow() {
      this.popupVisible = true;
    },
    addreshides() {
      this.popupVisible = false;
    },
    onValuesChange(picker, values) {
      picker.setSlotValues(1, Object.keys(citydatas[values[0]]));
      picker.setSlotValues(2, citydatas[values[0]][values[1]]);
      this.province = values[0];
      this.city = values[1];
      this.country = values[2];
    },
    carts() {
      this.$router.push("/cart");
    },
    detailScroll() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop > 10) {
        this.topbgc = true;
        if (
          scrollTop >= this.$refs.goods.offsetTop - 40 &&
          scrollTop <
            this.$refs.goods.offsetTop + this.$refs.goods.offsetHeight - 50
        ) {
          this.top = false;
          this.topx = true;
          this.topleave = false;
        } else if (
          scrollTop >=
          this.$refs.goods.offsetTop + this.$refs.goods.offsetHeight - 80
        ) {
          this.topx = false;
          this.topleave = true;
        }
        if (scrollTop < this.$refs.goods.offsetTop - 80) {
          this.top = true;
          this.topx = false;
          this.topleave = false;
        }
      } else if (scrollTop < 10) {
        this.topbgc = false;
      }
      // scrollTop > 10 ? (this.gotop = true) : (this.gotop = false);
    },
    topshow() {
      this.top = true;
      this.topx = false;
      this.topleave = false;
      let top = document.documentElement.scrollTop || document.body.scrollTop;
      // 实现滚动效果
      const timeTop = setInterval(() => {
        document.body.scrollTop = document.documentElement.scrollTop = top -= 20;
        if (top <= 0) {
          clearInterval(timeTop);
        }
      }, 10);
    },
    topshows() {
      this.topx = true;
      this.top = false;
      this.topleave = false;
      let top = document.documentElement.scrollTop || document.body.scrollTop;
      // 实现滚动效果
      const timeTop = setInterval(() => {
        document.body.scrollTop = document.documentElement.scrollTop = top += 20;
        if (top > this.$refs.goods.offsetTop - this.$refs.header.offsetHeight) {
          clearInterval(timeTop);
        }
      }, 15);
      const timeTops = setInterval(() => {
        document.body.scrollTop = document.documentElement.scrollTop = top -= 20;
        if (top < this.$refs.goods.offsetTop - this.$refs.header.offsetHeight) {
          clearInterval(timeTops);
        }
      }, 15);
    },
    topshowleave() {
      this.topx = false;
      this.top = false;
      // this.topleave  = true;
      let top = document.documentElement.scrollTop || document.body.scrollTop;
      // 实现滚动效果
      const timeTop = setInterval(() => {
        document.body.scrollTop = document.documentElement.scrollTop = top += 20;
        if (
          top >
          this.$refs.goods.offsetTop +
            this.$refs.goods.offsetHeight -
            this.$refs.header.offsetHeight
        ) {
          clearInterval(timeTop);
        }
      }, 10);
    },
    loadMore() {
      this.reqdetailList();
      this.page++;
    },
    beforeEnter(el) {
      //动画入场之前，此时还没有开始动画
      el.style.transform = "translateY(3.3rem)";
    },
    enter(el) {
      el.offsetWidth; //强制刷新动画
      el.style.transform = "translateY(-.3rem)";
      el.style.transition = "all .6s ";
    },
    afterEnter() {
      this.emshow = false;
    },
    addshow() {
      this.emshow = true;
      this.showmasks = true;
      let detailDatas = this.$store.state.detaildate;
      var isCart = this.$store.state.cartDatas.find((item) => {
        if (item.goods_id == detailDatas.goods_id) {
          item.valus += this.buyNum;
        }
        return item.goods_id == detailDatas.goods_id;
      });
      if (!isCart) {
        var addCartDatas = {
          goods_id: detailDatas.goods_id,
          goods_thumb: detailDatas.goods_thumb,
          goods_name: detailDatas.goods_name,
          shop_price: detailDatas.shop_price,
          valus: 1,
          isSelect: true,
        };
      }
      this.$store.commit("setCartDatas", addCartDatas);
    },
    swiperBigs() {
      this.swiperBig = false;
    },
    swipersm() {
      this.swiperBig = true;
    },
    shareshow() {
      this.showshare = true;
      if (!isweixin()) {
        this.thumhide = false;
      }
    },
    shareshowmask() {
      this.showshare = false;
    },
    weixinmask() {
      this.weixinImg = true;
      this.showshare = false;
    },
    shareImginfo(data) {
      this.weixinImg = data;
    },
    sharePosterFn() {
      this.porsters = true;
      this.showshare = false;
    },
    closeSharePoster() {
      this.porsters = false;
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    window.scroll(0, 0);
    let gid = this.$route.params.gid;
    this.goods_id = gid;
    this.reqdetails();
    this.$nextTick(() => {
      this.slots[0].defaultIndex = 15;
    });
    window.addEventListener("scroll", this.detailScroll, true);
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {
    window.removeEventListener("scroll", this.detailScroll, true);
  }, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.swiper_big {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #fff;
  z-index: 1000;
  .swipers_big {
    position: relative;
    top: 23%;
  }
}

.masker-leave-to {
  opacity: 0;
}
.masker-leave-active {
  transition: all 1.5s linear;
}
.detail {
  //分享
  .share_mask {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
    background: rgba(0, 0, 0, 0.5);
  }
  .share_info_shk {
    transform: translateY(10rem);
  }
  .share_info {
    width: 100%;
    height: 10rem;
    position: fixed;
    bottom: 0;
    left: 0;
    background-color: #fff;
    z-index: 999;
    transition: all 0.5s;
    .share {
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      .share_thum {
        flex: 1;
        .iconfont {
          font-size: 3.5rem;
          color: #80d640;
        }
        .share_title {
          margin-top: 0.3rem;
          font-size: 1.4rem;
        }
      }
    }
  }
  //-------
  .detail_fotter_mask {
    width: 30%;
    height: 15%;
    background: rgba(0, 0, 0, 0.5);
    position: fixed;
    top: 43%;
    left: 35%;
    z-index: 10000;
    border-radius: 0.6rem;
    color: #fff;
    display: flex;
    flex-direction: column;
    align-items: center;
    span {
      height: 65%;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 6rem;
      font-weight: 700;
    }
    i {
      height: 35%;
      width: 100%;
      font-style: normal;
      text-align: center;
      font-size: 1.4rem;
    }
  }
  .detail_tops {
    background-color: rgba(255, 255, 255, 0.8);
  }
  .detail_top {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 4rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 98;
    .top-back {
      width: 15%;
      height: 4rem;
      i {
        display: block;
        width: 100%;
        height: 4rem;
        line-height: 4rem;
        text-align: center;
        font-size: 1.6rem;
      }
      .top_backs {
        position: relative;
        color: #fff;
        &::after {
          content: "";
          display: block;
          position: absolute;
          top: 0.5rem;
          left: 1.5rem;
          width: 3rem;
          height: 3rem;
          background: rgba(41, 47, 54, 0.4);
          border-radius: 50%;
          z-index: -1;
        }
      }
    }
    .top-share {
      i {
        margin-left: 0.2rem;
      }
      .icon-fenxiang:before {
        margin-left: 0.3rem;
      }
    }
    .top_bgc {
      opacity: 1 !important;
    }
    .top_titel {
      width: 70%;
      opacity: 0;
      ul {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        li {
          flex: 1;
          height: 4rem;
          line-height: 4rem;
          text-align: center;
          font-size: 1.6rem;
        }
        .title-border {
          color: #f00;
          &::after {
            content: "";
            display: block;
            margin-top: -0.2rem;
            margin-left: 10%;
            width: 80%;
            height: 0.2rem;
            background-color: red;
          }
        }
      }
    }
  }
  .swipers {
    width: 100%;
    box-sizing: border-box;
    height: 37.5rem;
    padding: 0 !important;
    border-radius: 0;
    .mint-swipe-indicators {
      left: 50%;
      .mint-swipe-indicator {
        background-color: #999;
      }
      .is-active {
        opacity: 1;
        background: #ff976a;
      }
    }
    img {
      width: 100%;
      height: 37.5rem;
      border-radius: 0;
    }
  }
  .goods_price {
    padding: 1.1rem 1.1rem 0.8rem;
    background-color: #fff;
    display: flex;
    align-items: center;
    div {
      &::before {
        content: "¥";
        font-size: 1.4rem;
      }
    }
    .price {
      font-size: 2.2rem;
      font-weight: 700;
      color: rgb(242, 14, 40);
    }
    .old_price {
      font-size: 1.4rem;
      color: rgb(153, 153, 153);
      margin-top: -0.3rem;
      margin-left: 0.8rem;
      text-decoration: line-through;
    }
  }
  .detail_goods_title {
    padding: 0 1.1rem 1.1rem;
    background-color: #fff;
    line-height: 2.5rem;
    font-size: 1.5rem;
    text-align: left;
    max-height: 8rem;
  }
  .detail-location {
    padding: 0 1.1rem 1.1rem;
    display: flex;
    align-items: center;
    background-color: #fff;
    font-size: 1.4rem;
    color: #999;
    margin-bottom: 1rem;
    div {
      flex: 1;
      text-align: center;
    }
    .sales {
      text-align: left;
    }
    .site {
      text-align: right;
    }
  }
  .detail-inte {
    width: 100%;
    background-color: #fff;
    margin-bottom: 1rem;
    div {
      padding: 1.3rem 1.3rem 1.3rem 1.5rem;
      color: #999;
      font-size: 1.4rem;
      span {
        color: #333;
      }
    }
    .give {
      border-bottom: 1px solid #efefef;
      position: relative;
      i {
        margin-left: 16rem;
        color: #333;
        font-size: 1.4rem;
        position: absolute;
        right: 1rem;
      }
    }
  }
  .goods_select {
    padding: 1.3rem 1.5rem;
    background-color: #fff;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    .setect {
      flex: 1;
      text-align: left;
      font-size: 1.4rem;
      color: #999;
      span {
        color: #333;
      }
    }
    i {
      flex: 1;
      text-align: right;
      font-size: 1.4rem;
    }
  }
  .num-mask {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 101;
  }
  .godds_masks {
    transform: translateY(34vh);
  }
  .godds_mask {
    width: 100%;
    height: 30.7vh;
    position: fixed;
    bottom: 0;
    left: 0;
    background-color: #fff;
    border-top-left-radius: 1rem;
    border-top-right-radius: 1rem;
    z-index: 102;
    transition: all 0.5s;
    .attr-goods-header {
      position: relative;
      padding: 1.1rem;
      .goods_img {
        width: 9rem;
        height: 9rem;
        position: absolute;
        top: -2rem;
        border-radius: 0.6rem;
        overflow: hidden;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .goods_info {
        margin-left: 10rem;
        height: 1.5rem;
        .info_goods_titel {
          font-size: 1.5rem;
          margin-bottom: 0.5rem;
          padding-right: 1.5rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
        }
        .info_price {
          font-size: 1.8rem;
          color: #f92028;
          margin-bottom: 0.3rem;
        }
        .info_volum {
          font-size: 1.2rem;
          color: #888;
        }
        i {
          font-size: 1.8rem;
          position: absolute;
          top: 1rem;
          right: 0.6rem;
        }
      }
      .goods_number {
        padding: 1.1rem;
        display: flex;
        align-items: center;
        margin-top: 7.5rem;
        margin-bottom: 0.5rem;
        .number {
          flex: 1;
          font-size: 1.4rem;
          color: #888;
          text-align: left;
        }
        .stepper {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          .disableds {
            background-color: #f8f8f8;
          }
          button {
            width: 3rem;
            height: 2.6rem;
            border: 1px solid #eee;
            background-color: #fff;
            border-radius: 5px 0 0 5px;
            font-size: 1.4rem;
            color: #333;
          }
          button:last-child {
            border-radius: 0 5px 5px 0;
          }
          input {
            width: 4rem;
            height: 2.4rem;
            background-color: #fff;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
            color: #333;
            font-size: 1.4rem;
            text-align: center;
            line-height: 2.4rem;
          }
        }
      }
      .goods_footer {
        width: 100%;
        width: calc(100% + 2rem);
        margin-left: -1rem;
        height: 5rem;
        display: flex;
        font-size: 1.6rem;
        .foobuy {
          width: 50%;
          height: 5rem;
          line-height: 5rem;
          text-align: center;
          background-color: #fba534;
          color: #fff;
        }
        .foocart {
          width: 50%;
          background-color: #f92028;
          color: #fff;
          height: 5rem;
          line-height: 5rem;
          text-align: center;
        }
      }
    }
  }
  .goods_tabs {
    .is-selected {
      border: 0;
      color: #f44;
      &::after {
        content: "";
        display: block;
        width: 30%;
        height: 0.2rem;
        background-color: #f44;
        margin-left: 35%;
        margin-top: 0.5rem;
      }
    }
    .mint-tab-item {
      padding: 0.9rem 0 1.2rem;
      .mint-tab-item-label {
        font-size: 1.4rem;
        height: 100%;
      }
    }
    .goods_page {
      width: 100%;
      img {
        width: 100%;
      }
      .s-img {
        margin-bottom: -0.4rem;
        img {
          width: 100% !important;
        }
      }
      em {
        display: none;
      }
    }
    .standard {
      padding: 1rem;
      background-color: #fff;
      table {
        border: 1px solid #ccc;
        border-collapse: collapse;

        width: 100%;
        tr {
          font-size: 1.2rem;
          th {
            padding: 0.8rem;
            text-align: left;
            padding-left: 1rem;
          }
          td {
            padding: 0.8rem;
            border: 1px solid #ccc;
            text-align: left;
            &:first-child {
              width: 25% !important;
            }
          }
        }
      }
    }
  }
  .footer {
    width: 100%;
    height: 5rem;
    position: fixed;
    bottom: 0;
    left: 0;
    background-color: #fff;
    display: flex;
    align-items: center;
    div {
      flex: 1;
      text-align: center;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-right: 1px solid #efefef;
      i {
        font-size: 1.8rem;
      }
      span {
        font-size: 1.2rem;
      }
    }
    .footer_cart {
      position: relative;
      .cart_info {
        min-width: 1.4rem;
        line-height: 1.4rem;
        border-radius: 0.7rem;
        position: absolute;
        color: #fff;
        background-color: red;
        text-align: center;
        top: -0.3rem;
        right: 0.8rem;
      }
      em {
        font-weight: 700;
        font-style: normal;
        color: #d93a3a;
        position: absolute;
        font-size: 1.6rem;
        top: -3.3rem;
        right: 1.3rem;
      }
    }
    .footer_gocart {
      flex: 2;
      height: 5rem;
      font-size: 1.4rem;
      color: #fff;
      background-color: #f92028;
      border: 0;
    }
    .footer_gobuy {
      flex: 2;
      height: 5rem;
      font-size: 1.4rem;
      color: #fff;
      background-color: #fba534;
      border: 0;
    }
  }
  .address {
    .mint-popup-bottom {
      width: 100%;
      overflow: hidden;
      border-top-left-radius: 2rem;
      border-top-right-radius: 2rem;
    }
    .mint-popup {
      transition: 0.5s ease-out;
    }
    .addres {
      width: 100%;
      height: 50vh;
      background-color: #fff;
      .addres_titel {
        height: 3rem;
        width: 100%;
        display: flex;
        align-items: center;
        span {
          margin-top: 1rem;
          width: 85%;
          display: inline-block;
          text-align: center;
          text-indent: 8rem;
          font-size: 1.6rem;
        }
        i {
          width: 15%;
          display: inline-block;
          text-align: right;
          text-indent: 2rem;
          padding-right: 1.5rem;
          margin-top: 1rem;
          font-size: 1.6rem;
        }
      }
      .picker {
        position: relative;
        top: 8rem;
        .picker-slot-divider {
          margin-top: 3rem;
          font-size: 2rem;
        }
        .picker-center-highlight:before {
          top: 16px;
        }
        .picker-center-highlight:after {
          bottom: -20px;
        }
      }
    }
  }
}
</style>