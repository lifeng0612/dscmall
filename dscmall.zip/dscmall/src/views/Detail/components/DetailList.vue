<!--  -->
<template>
  <div class="DetailList">
    <div class="List_love">
      <span>猜你喜欢</span>
    </div>
    <div class="List">
      <ul>
        <li v-for="detaillist in detaillists" :key="detaillist.goods_id">
          <router-link :to="'/goodsdetail/' + detaillist.goods_id">
              <img :src="detaillist.goods_thumb" alt="" />
          <div class="list">
            <div class="List_title">{{ detaillist.goods_name }}</div>
            <div class="List_price">{{ detaillist.shop_price_formated }}</div>
          </div>
          </router-link>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: ["detaillists"],
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
      
  },
  mounted() {},
};
</script>
<style lang="less">
.DetailList {
    margin-bottom: 5rem;
  width: 100%;
  .List_love {
    width: 100%;
    height: 5rem;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 1.5rem;
    span {
      padding: 1rem 0.6rem;
      font-size: 1.4rem;
      position: relative;
      color: #888;
      &::before {
        content: "";
        display: inline-block;
        height: 1px;
        width: 5rem;
        background-color: #ccc;
        position: absolute;
        top: 50%;
        left: -5rem;
      }
      &::after {
        content: "";
        display: inline-block;
        height: 1px;
        width: 5rem;
        background-color: #ccc;
        position: absolute;
        top: 50%;
        right: -5rem;
      }
    }
  }
  .List {
    width: calc(100% - 1rem);
    margin-left: 0.5rem;

    ul {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      li {
        box-sizing: border-box;
        width: 50%;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        border-radius: 1rem;
        margin-bottom: 0.5rem;
        &:nth-child(2n-1) {
          padding-right: 0.3rem;
        }
        &:nth-child(2n) {
          padding-left: 0.3rem;
        }
        img {
          width: 100%;
          height: 17.8rem;
          border-top-left-radius: 1rem;
          border-top-right-radius: 1rem;
        }
        .list {
          background-color: #fff;
          .List_title {
            font-size: 1.4rem;
            padding: 0.8rem;
            height: 3.8rem;
            line-height: 2.2rem;
            overflow: hidden;
            -webkit-box-orient: vertical;
            display: -webkit-box;
            text-overflow: ellipsis;
            -webkit-line-clamp: 2;
          }
          .List_price {
            padding: 0.6rem 0;
            color: #f44;
            font-weight: 700;
            font-size: 1.4rem;
            text-align: center;
            margin-bottom: 0.5rem;
          }
        }
      }
    }
  }
}
</style>