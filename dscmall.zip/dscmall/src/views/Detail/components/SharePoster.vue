<!--  -->
<template>
  <div class="SharePoster" v-if="porsters">
    <div class="SharePosters" @click="closePoster"></div>
    <div class="share_content">
      <div class="share_text">
        长按保存到相册
        <!-- <span @click="posterImg"
          ><i class="iconfont icon-jiazai" ref="transi"></i> 点击切换图片</span
        > -->
      </div>
      <div class="close_share" @click="closePoster">
        <img src="@/assets/img/poster-close.png" alt="" />
      </div>
      <div class="share_img">
        <img :src="posterImage" alt="" />
      </div>
    </div>
    <div class="poster_canvas">
      <div class="hideCanvas">
        <canvas ref="canvaser"></canvas>
      </div>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    porsters: Boolean,
    posterDatas: Object,
  },
  data() {
    //这里存放数据
    return {
      posterImage: "",
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {
    porsters() {
      if (this.porsters == true) {
        this.$nextTick(() => {
          this.saveposter();
        });
      }
    },
  },
  //方法集合
  methods: {
    closePoster() {
      this.$emit("closeSharePoster");
    },
    saveposter() {
      var canvas = this.$refs.canvaser;
      var ctx = canvas.getContext("2d");

      let W = window.screen.availWidth; //获取屏幕的宽度，不包含任务栏
      let H = window.screen.availHeight; //获取屏幕的高度，不包含任务栏
      let devicePixelRatio = window.devicePixelRatio || 1;
      let backingPixelRatio = ctx.webkitBackingStorePixelRatio || 1;
      let ratio = devicePixelRatio / backingPixelRatio; //计算出比例

      canvas.width = W * ratio;
      canvas.height = H * ratio;
      canvas.style.width = W * ratio + "px"; //设置canvas容器的宽度
      canvas.style.height = H * ratio + "px"; //设置canvas容器的高度
      ctx.scale(ratio, ratio); //将对象内容缩放
      var imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      //定义一个白色画布
      for (var i = 0; i < imgData.data.length; i += 4) {
        imgData.data[i] = 255;
        imgData.data[i + 1] = 255;
        imgData.data[i + 2] = 255;
        imgData.data[i + 3] = 255;
      }

      ctx.putImageData(imgData, 0, 0);

      //生成图像
      var img = new Image(); //定义一个图片对象
      img.src = this.posterDatas.image;
      img.onload = function () {
        ctx.drawImage(img, 0, 0, W, W);
      };
      // 生成标题
      ctx.font = "20px Arial"; //设置字体大小
      ctx.fillStyle = "#333333"; //设置字体的颜色
      let title = this.posterDatas.title;
      this.titleAutoLine(title, canvas, 20, W + 30, 30, W - 40, 2);

      // 生成价格
      ctx.font = "30px Arial"; //设置字体大小
      ctx.fillStyle = "#FF4444"; //设置字体的颜色
      ctx.textAlign = "center"; //设置文本的对齐方式
      ctx.fillText("￥" + this.posterDatas.price, W / 2, W + 100);

      //生成二维码图像图像
      var img2 = new Image(); //定义一个图片对象
      img2.src = this.posterDatas.code;
      // console.log(img);
      img2.onload = function () {
        ctx.drawImage(img2, 100, W + 160, W / 3, W / 3);
      };
      // 用定时器模拟异步
      setTimeout(() => {
        this.posterImage = canvas.toDataURL();
      }, 500);
    },
    titleAutoLine(title, canvas, x, y, lineHeight, canvasWidth, lines) {
      var ctx = canvas.getContext("2d");
      var lineWidth = 0; //文本宽度
      var lastSubStringIndex = 0; //标题字符串的索引
      var beginY = y; //文本起始位置的y

      for (let i = 0; i < title.length; i++) {
        lineWidth += ctx.measureText(title[i]).width;
        if (lineWidth > canvasWidth) {
          if (y >= beginY + lineHeight * (lines - 1)) {
            ctx.fillText(
              title.substring(lastSubStringIndex, i - 5) + "...",
              x,
              y
            );
            return;
          } else {
            ctx.fillText(title.substring(lastSubStringIndex, i), x, y);
            y += lineHeight;
            lineWidth = 0;
            lastSubStringIndex = i;
          }
        }
      }
    },
  },
};
</script>
<style lang="less">
.SharePoster {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1000;
  .poster_canvas {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    .hideCanvas {
      display: none;
    }
  }
  .SharePosters {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
  }
  .share_content {
    width: calc(100% - 30%);
    margin-left: 15%;
    height: calc(100% - 30%);
    margin-top: 20%;
    background-color: #fff;
    position: relative;
    z-index: 1000;
    .close_share {
      position: absolute;
      right: 0;
      top: -3rem;
      img {
        height: 3rem;
      }
    }
    .share_img {
      width: 100%;
      img {
        width: 100%;
      }
    }
    .share_text {
      z-index: 1000;

      position: absolute;
      width: 100%;
      height: 4.4rem;
      line-height: 4.4rem;
      bottom: -4.4rem;
      left: 0;
      color: #fff;
      font-size: 1.4rem;
      display: flex;
      justify-content: center;
      span {
        width: 50%;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        i {
          margin-right: 0.5rem;
          color: #fff;
          font-size: 1.3rem;
        }
        #transi {
          transform: rotateZ(360deg);
          transition: all 0.8s linear;
        }
      }
    }
  }
}
</style>