<!--  -->
<template>
<div class='ShareInfo'>
    <div class="share_img" @click="imgMask" v-if="weixinImg">
        <img src="@/assets/img/share-bg.png" alt="">
    </div>
</div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
//import引入的组件需要注入到对象中才能使用
components: {},
props:{
    weixinImg:Boolean
},
data() {
//这里存放数据
return {
    
};
},
//监听属性 类似于data概念
computed: {},
//监控data中的数据变化
watch: {},
//方法集合
methods: {
    imgMask(){
       this.$emit("shareImginfo",false)
    }
},
}
</script>
<style lang="less">
    .ShareInfo{
        .share_img{
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 999;
            img{
                width: 100%;
                height: 100%;
            }
        }
    }
</style>