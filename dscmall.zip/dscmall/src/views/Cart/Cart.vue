<!--  -->
<template>
  <div class="cart">
    <div class="flow_cart">
      <div class="cart_top" v-if="!cartDatas.length > 0">
        <div class="flow_img">
          <img
            src="https://x.dscmall.cn/static/dist/img/cart-empty.png"
            alt=""
          />
        </div>
        <h3>您的购物车还是空空的，快去逛逛吧！</h3>
        <div class="flow_bttn">
          <router-link to="/home">
            <div class="btn_stroll">去逛逛</div>
          </router-link>
          <div class="btn_atten">看看关注</div>
        </div>
      </div>
      <div class="cart_sh" v-else>
        <ul>
          <li v-for="(cart, index) in cartDatas" :key="index">
            <div class="carsh_left" @click="select(cart,index)">
              <i class="iconfont icon-danxuankuang" v-if="!cart.isSelect"></i>
              <i class="iconfont icon-danxuankuangxuanzhong" v-else></i>
            </div>
            <div class="carsh_right" @click="toher(cart.goods_id)">
              <div class="car_img">
                <img :src="cart.goods_thumb" alt="" />
              </div>
              <div class="car_content">
                <div class="car_text">{{ cart.goods_name }}</div>
                <div class="car_cxt">
                  <div class="car_price">{{ cart.shop_price }}</div>
                  <div class="cxt">
                    <a href="javascript:;" @click.stop="reducecart(index)">-</a>
                    <input type="text" v-model.number="cart.valus" @click.stop/>
                    <a href="javascript:;" @click.stop="addcart(index)">+</a>
                    <i class="iconfont icon-shoucang1"></i>
                    <i class="iconfont icon-shanchu" @click.stop="clearcart(index)"></i>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="total_price">
      <div class="selectAll" @click="changeselectAll">
        <i class="iconfont icon-danxuankuang" v-if="!selectAll"></i>
        <i class="iconfont icon-danxuankuangxuanzhong" v-else></i>
        全选
      </div>
      <div class="price">
        <div class="All">
          合计：<span>{{total.toFixed(2)}}</span>
        </div>
        <div class="tice_price">(不含运费，已节省 <span>10</span>)</div>
      </div>
      <div class="settlement">
        去结算({{totalNum}})
      </div>
    </div>
    <CartList></CartList>
    <Footer></Footer>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Footer from "../../components/Footer.vue";
import CartList from "./components/CartList";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    Footer,
    CartList,
  },
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {
    cartDatas() {
      return this.$store.state.cartDatas;
    },
    selectAll(){
      let radionum = this.$store.state.cartDatas.every(item => {
            return item.isSelect == true
        })
        return radionum
    },
    total(){
      let totalprice = 0;
      this.$store.state.cartDatas.map(item=>{
        if(item.isSelect){
          totalprice +=item.valus * item.shop_price
        }
      })
      return totalprice
    },
    totalNum(){
      let totalnum = 0;
      this.$store.state.cartDatas.map(item=>{
        if(item.isSelect){
          totalnum +=item.valus
        }
      })
      return totalnum
    }
  },
  //监控data中的数据变化
  watch: {
  
  },
  //方法集合
  methods: {
    select(cart,index){
      cart.isSelect = !cart.isSelect
      this.$store.commit("select",{cart,index})
    },
    changeselectAll(){
      this.$store.commit("changeselectAll")
    },
    //商品++
    addcart(index){
      this.$store.commit("addcart",index)
    },
    //商品--
    reducecart(index){
      this.$store.commit("reducecart",index)
    },
    //删除
    clearcart(index){
      this.$store.commit("clearcart",index)
    },
    toher(goods_id){
      this.$router.push("/goodsdetail/"+goods_id)
    }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    window.scroll(0, 0);
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.cart {
  .flow_cart {
    width: calc(100% - 2rem);
    margin: 1rem;
    padding-bottom: 3rem;
    overflow: hidden;
    .cart_top {
        padding: 3rem;
      background-color: #fff;
      .flow_img {
        margin: 1rem auto 0;
        width: 10rem;
        height: 10rem;
        img {
          width: 100%;
          height: 100%;
        }
      }
      h3 {
        margin-top: 1.5rem;
        font-size: 1.3rem;
        text-align: center;
      }
      .flow_bttn {
        margin-top: 1.5rem;
        display: flex;
        a{
            margin-left: -3rem;
        }
        div {
          padding: 0.2rem 1rem;
          text-align: center;
          border: 1px solid #efefef;
          color: #333;
          font-size: 1.4rem;
        }
        .btn_stroll {
          margin-left: 10rem;
        }
        .btn_atten {
          margin-left: 1rem;
        }
      }
    }
    .cart_sh {
      width: 100%;
      ul {
        width: 100%;
        li {
          width: 100%;
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
          .carsh_left {
            width: 10%;
            text-align: center;
            i{
                font-size: 1.6rem;
            }
            .icon-danxuankuangxuanzhong{
                color: #f44;
            }
          }
          .carsh_right {
            border-radius: 1rem;
            box-sizing: border-box;
            background-color: #fff;
            padding: 2% 3%;
            width: 87%;
            display: flex;
            align-items: center;
            .car_img {
              width: 7rem;
              img {
                width: 7rem;
              }
            }
            .car_content {
              width: 100%;
              width: calc(100% - 1rem);
              margin-left: 1rem;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              align-items: center;
              .car_text {
                width: 100%;
                height: 3.5rem;
                line-height: 1.6rem;
                display: -webkit-box;
                overflow: hidden;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                margin-bottom: .8rem;
              }
              .car_cxt {
                width: 100%;
                display: flex;
                justify-content: space-between;
                align-items: center;
                .car_price{
                    font-size: 1.8rem;
                    color: #f44;
                    &::before{
                        content: "¥";
                        font-size: 1.4rem;
                    }
                }
                .cxt {
                  width: 70%;
                  display: flex;
                  justify-content: flex-end;
                  align-items: center;
                  a {
                    width: 2rem;
                    height: 1.6rem;
                    line-height: 1.6rem;
                    border: 1px solid #eee;
                    background-color: #fff;
                    border-radius: 5px 0 0 5px;
                    font-size: 1.4rem;
                    color: #333;
                    text-align: center
                  }
                  a:nth-of-type(2) {
                    border-radius: 0 5px 5px 0;
                  }
                  input {
                    width: 3rem;
                    height: 1.6rem;
                    background-color: #fff;
                    border-top: 1px solid #eee;
                    border-bottom: 1px solid #eee;
                    color: #333;
                    font-size: 1.2rem;
                    text-align: center;
                    line-height: 1.6rem;
                  }
                  .icon-shoucang1{
                      margin: 0 .6rem;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  .total_price{
    width: 100%;
    height: 4.4rem;
    position: fixed;
    bottom: 5rem;
    left: 0;
    background-color: #fff;
    z-index: 99;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 1.4rem;
    .selectAll{
      width: 20%;
      text-align: center;
      .icon-danxuankuangxuanzhong{
        color: #f44;
      }
    }
    .price{
      text-align: right;
      width: 55%;
      box-sizing: border-box;
      padding-right: 1.6rem;
      span{
        &::before{
          content: "¥";
          font-size: 1.2rem;
        }
      }
      .All{
        padding-right: 1rem;
        span{
          font-size: 1.8rem;
          color: rgb(242, 14, 40);
          font-weight: 700;
        }
      }
      .tice_price{
        font-size: 1.2rem;
        color: #999;
      }
    }
    .settlement{
      width: 25%;
      background: #f44;
      color: #fff;
      text-align: center;
      line-height: 4.4rem;
    }
  }
}
</style>