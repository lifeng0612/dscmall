<!--  -->
<template>
  <div class="category-header">
    <section>
      <form action="">
        <div class="seach-wrap">
          <div class="back">
            <a
              href="javascript:;"
              class="iconfont icon-jiantou3"
              onclick="window.history.back()"
            ></a>
          </div>
          <div class="input">
            <input type="text"  @click="search" v-model="titletop"/>
            <i class="iconfont icon-sousuo2"></i>
          </div>
          <div class="back" v-if="this.$route.path != '/category'" @click="catechange">
            <a v-if="hesderchage"
              href="javascript:;"
              class="iconfont icon-leimupinleifenleileibie"
            ></a>
            <a v-if="!hesderchage"
              href="javascript:;"
              class="iconfont icon-icon-viewlist"
              style="font-size:1.6rem"
            ></a>
          </div>
        </div>
      </form>
    </section>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props:["titletop"],
  data() {
    //这里存放数据
    return {
      hesderchage:true
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {
   
  },
  //方法集合
  methods: {
    search(){
      this.$router.push("/search");
    },
    catechange(){
      this.hesderchage = !this.hesderchage;
      this.$emit("toparent",this.hesderchage)
    }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.category-header {
  width: 100%;
  height: 5rem;
  box-sizing: border-box;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 99;
  border-bottom: 1px solid #efefef;
  background-color: #fff;
  padding: 0.8rem 0;
  section {
    width: 100%;
    height: 100%;
    form {
      width: 100%;
      height: 100%;
      .seach-wrap {
        width: 100%;
        height: 100%;
        display: flex;
        .back {
          width: 10%;
          a {
            width: 100%;
            height: 100%;
            text-indent: 1rem;
            display: flex;
            align-items: center;
            font-size: 1.8rem;
          }
        }
        .input {
          width: 80%;
          display: flex;
          position: relative;
          input {
            border: 1px solid #ccc;
            border-radius: 50px;
            width: 100%;
            height: 100%;
            text-indent: 1.5rem;
          }
          i {
            width: 3rem;
            height: 100%;
            position: absolute;
            top: 0;
            right: .6rem;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #888;
            font-size: 1.6rem;
          }
        }
      }
    }
  }
}
</style>