<!--  -->
<template>
  <div class="CategoryNav">
    <div
      class="CategoryNav-slide"
      v-for="(categorydata, index) in categorydatas"
      :key="categorydata.cat_id"
    >
      <p
        :class="{ actives: activeindex == index }"
        @click="changeactive(index)"
      >
        <span>{{ categorydata.cat_name }}</span>
      </p>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    categorydatas: Array,
  },
  data() {
    //这里存放数据
    return {
      activeindex: 0,
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    changeactive(index) {
      this.activeindex = index;
      this.$emit("toparent", index);
      // this.$emit("toparents",cat_id)
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.CategoryNav {
  position: fixed;
  width: 20%;
  height: 100%;
  // float: left;
  border-right: 1px solid #efefef;
  .CategoryNav-slide {
    p {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      span {
        width: 100%;
        display: inline-block;
        height: 3.8rem;
        line-height: 3.8rem;
        text-indent: 1.5rem;
        color: #999;
        font-size: 1.2rem;
      }
    }
    .actives::before {
      content: "";
      width: 2px;
      height: 18px;
      background-color: red;
    }
    .actives {
      span {
        color: red;
      }
    }
  }
}
</style>