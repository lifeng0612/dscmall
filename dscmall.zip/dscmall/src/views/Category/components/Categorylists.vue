<!--  -->
<template>
  <div
    :class="{ Categorylists: true, categoryfixed: this.maskshow }"
    v-infinite-scroll="loadMore"
    infinite-scroll-disabled="loading"
  >
    <Loading v-if="isShowLoading"></Loading>
    <CategoryHeader @toparent="getSonFn"></CategoryHeader>
    <NavigationList
      @toparent="getorder"
      @toparentsort="getsort"
      @toparentsorts="getsorts"
      @toparentoders="getoders"
      @toparentmask="getshow"
    ></NavigationList>
    <div class="cate">
      <div
        :class="catelist ? 'category-list' : 'category-list2'"
        v-for="(catetypelist, goods_id, index) in catetypelists"
        :key="index"
      >
        <router-link :to="'/goodsdetail/' + catetypelist.goods_id">
          <div class="list-img">
            <img :src="catetypelist.goods_thumb" alt="" />
          </div>
          <div class="list-title">
            <h4>
              {{ catetypelist.goods_name }}
            </h4>
            <h5>{{ catetypelist.shop_price_formated }}</h5>
            <div class="title-bottom">
              <span class="bot-tle">进店</span>
              <span class="pre">{{ catetypelist.sales_volume }}人已购买</span>
              <i class="iconfont icon-gouwuche1"></i>
            </div>
          </div>
        </router-link>
      </div>
    </div>
    <transition name="mask">
      <div class="mask" v-if="this.maskshow">
        <div class="mask-title">
          <p>自营产品</p>
          <mt-switch></mt-switch>
        </div>
        <div class="mask-label">
          <div class="label-sort">仅看有货</div>
          <div class="label-prom">促销</div>
        </div>
        <div class="price">
          <div>价格区间</div>
          <input type="text" v-model="min" placeholder="最低价" /> —
          <input type="text" v-model="max" placeholder="最高价" />
        </div>
        <div class="mask-botton">
          <div class="close" @click="close">关闭</div>
          <div class="confi" @click="confn">确定</div>
        </div>
      </div>
    </transition>
    <QuickNavigation></QuickNavigation>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import CategoryHeader from "./CategoryHeader";
import QuickNavigation from "@/components/QuickNavigation";
import NavigationList from "@/components/NavigationList";
import { getcates } from "@/api/api";
import Loading from "@/components/Loading";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    CategoryHeader,
    QuickNavigation,
    NavigationList,
    Loading,
  },
  data() {
    //这里存放数据
    return {
      catelist: true,
      catetypelists: [],
      order: "desc",
      sort: "goods_id",
      page: "1",
      size: "10",
      osort: "shop_price",
      min: "",
      max: "",
      isShowLoading: false,
      dilist: false,
      maskshow: false,
      pageactive:false
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    getSonFn(data) {
      this.catelist = data;
    },
    async getlist(cat_id, size, page, order, sort, min, max) {
      this.isShowLoading = true;
      let result = await getcates(
        "/catalog/goodslist",
        {
          cat_id,
          size,
          page,
          order,
          sort,
          min,
          max,
        },
        "post"
      );
      // console.log(result.data);
      if (result.data.length > 0) {
        let results = result.data;
        this.catetypelists = this.catetypelists.concat(results);
        this.isShowLoading = false;
      } else {
        this.dilist = true;
        this.isShowLoading = false;
      }
    },
    getorder(data) {
       this.pageactive = false
      this.page = "1";
      this.size = "113";
      this.catetypelists = [];
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        data,
        this.sort,
        this.min,
        this.max
      );
    },
    getsort(data) {
       this.pageactive = false
      this.page = "1";
      this.size = "113";
      this.catetypelists = [];
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        this.order,
        data,
        this.min,
        this.max
      );
    },
    getsorts(data) {
       this.pageactive = false
      this.page = "1";
      this.size = "113";
      this.catetypelists = [];
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        this.order,
        data,
        this.min,
        this.max
      );
    },
    getoders(data) {
       this.pageactive = false
      this.page = "1";
      this.size = "113";
      this.catetypelists = [];
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        data,
        this.osort,
        this.min,
        this.max
      );
    },
    loadMore() {
      if(this.pageactive){
        this.page = "2";
        this.pageactive = false
      }
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        this.order,
        this.sotr,
        this.min,
        this.max
      );
      this.page++;
    },
    getshow(data) {
      this.maskshow = data;
    },
    close() {
      this.maskshow = false;
      this.pageactive = true
      this.min = "";
      this.max = "";
      this.sort = "goods_id";
      this.page = "1";
      this.catetypelists = [];
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        this.order,
        this.sotr,
        this.min,
        this.max
      );
    },
    confn() {
       this.pageactive = false
      this.maskshow = false;
       this.page = "1";
      this.size = "113";
      this.sort = "goods_id";
      this.catetypelists = [];
      this.getlist(
        this.$route.params.cid,
        this.size,
        this.page,
        this.order,
        this.sotr,
        this.min,
        this.max
      );
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.mask-enter,
.mask-leave-to {
  transform: translateX(100%);
}
.mask-enter-active,
.mask-leave-active {
  transition: all .5s ease;
}
.mint-switch-input:checked + .mint-switch-core {
  border-color: #f92028;
  background-color: #f92028;
}
.mint-switch-core {
  width: 44px;
  height: 27px;
  border-radius: 17px;
  display: inline-block;
  position: relative;
  border: 1px solid #d9d9d9;
  box-sizing: border-box;
  background: #d9d9d9;
}
.mint-switch-core::after {
  width: 25px;
  height: 25px;
  background-color: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
}
.mint-switch-core::before {
  width: 44px;
  height: 25px;
  background-color: #efefef;
}
.categoryfixed {
  position: fixed;
  top: 0;
  left: 0;
}
.Categorylists {
  .mask {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    background-color: #f4f4f4;
    z-index: 99;
    .mask-title {
      padding: 1rem;
      line-height: 2rem;
      background-color: #fff;
      margin-bottom: 1.5rem;
      display: flex;
      p {
        flex: 1;
        font-size: 1.4rem;
      }
    }
    .mask-label {
      padding: 1rem 0 0 1rem;
      background-color: #fff;
      margin-bottom: 1.5rem;
      display: flex;
      div {
        width: 30%;
        height: 2.5rem;
        line-height: 2.5rem;
        background-color: #efefef;
        text-align: center;
        margin-bottom: 1rem;
        margin-left: 1rem;
      }
    }
    .price {
      width: 100%;
      padding: 1rem;
      background-color: #fff;
      div {
        margin-bottom: 0.2rem;
        padding-bottom: 1rem;
        border-bottom: 1px solid #efefef;
        font-size: 1.4rem;
      }
      input {
        width: 35%;
        padding: 1rem;
        height: 2rem;
        line-height: 2rem;
        text-align: center;
        background-color: #efefef;
        margin-left: 2%;
        margin-top: 1rem;
      }
    }
    .mask-botton {
      width: 100%;
      height: 5rem;
      position: fixed;
      bottom: 0;
      left: 0;
      background-color: #fff;
      display: flex;
      div {
        flex: 1;
        font-size: 1.6rem;
        text-align: center;
        width: 100%;
        height: 5rem;
        line-height: 5rem;
      }
      .confi {
        color: #fff;
        background-color: #e93b3d;
      }
    }
  }
  .cate {
    width: calc(100% - 10px);
    margin-left: 5px;
    margin-right: 5px;
    margin-top: 0.6rem;
    display: flex;
    flex-wrap: wrap;
    .category-list {
      box-sizing: border-box;
      width: 50%;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border-radius: 0.6rem;
      margin-bottom: 0.5rem;
      &:nth-child(2n-1) {
        padding-right: 0.3rem;
      }
      &:nth-child(2n) {
        padding-left: 0.3rem;
      }
      .list-img {
        width: 17.8rem;
        height: 17.8rem;
        img {
          width: 100%;
          height: 100%;
        }
      }
      .list-title {
        box-sizing: border-box;
        padding: 0.6rem 1rem;
        background-color: #fff;
        border-radius: 0.6rem;
        h4 {
          font-weight: normal;
          font-size: 1.4rem;
          color: #333;
          height: 4rem;
          line-height: 2rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        h5 {
          font-size: 1.4rem;
          color: rgb(242, 14, 40);
        }
        .title-bottom {
          padding: 0.8rem 0.1rem 0.2rem;
          display: flex;
          align-items: center;
          position: relative;
          .bot-tle {
            background-color: #fef0f0;
            padding: 0.1rem 0.5rem;
            border-radius: 0.2rem;
            color: #f92028;
            font-size: 1.3rem;
            float: left;
          }
          .pre {
            color: #666;
            font-size: 1.2rem;
            float: left;
            margin-left: 0.5rem;
          }
          i {
            position: absolute;
            top: 0.9rem;
            right: 0;
            color: #f00;
            font-size: 1.6rem;
          }
        }
      }
    }
    .category-list2 {
      box-sizing: border-box;
      width: 100%;
      display: flex;
      overflow: hidden;
      border-radius: 0.6rem;
      margin-bottom: 0.5rem;
      a {
        display: inherit;
      }
      .list-img {
        width: 9rem;
        height: 9rem;
        img {
          width: 9rem;
          height: 100%;
        }
      }
      .list-title {
        box-sizing: border-box;
        padding: 0.6rem 1rem;
        background-color: #fff;
        border-radius: 0.6rem;
        h4 {
          font-weight: normal;
          font-size: 1.4rem;
          color: #333;
          height: 4rem;
          line-height: 2rem;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        h5 {
          font-size: 1.4rem;
          color: rgb(242, 14, 40);
        }
        .title-bottom {
          padding: 0.8rem 0.1rem 0.2rem;
          display: flex;
          align-items: center;
          position: relative;
          .bot-tle {
            background-color: #fef0f0;
            padding: 0.1rem 0.5rem;
            border-radius: 0.2rem;
            color: #f92028;
            font-size: 1.3rem;
            float: left;
          }
          .pre {
            color: #666;
            font-size: 1.2rem;
            float: left;
            margin-left: 0.5rem;
          }
          i {
            position: absolute;
            top: 0.9rem;
            right: 0;
            color: #f00;
          }
        }
      }
    }
  }
}
</style>