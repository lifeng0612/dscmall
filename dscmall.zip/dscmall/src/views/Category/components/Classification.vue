<!--  -->
<template>
  <div class="Classification">
    <Loading v-if="isShowLoading"></Loading>
    <CategoryNav
      :categorydatas="categorydatas"
      @toparent="getIndex"
    ></CategoryNav>
    <CategoryList :catelists="catelists" :ad="ad"></CategoryList>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import CategoryNav from "./CategoryNav";
import CategoryList from "./CategoryList";
import { getClassifyList, getpages } from "@/api/api";
import Loading from "@/components/Loading";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    CategoryNav,
    CategoryList,
    Loading,
  },
  data() {
    //这里存放数据
    return {
      categorydatas: [],
      catelists: [],
      getcatelists: ["858", "6", "8", "3", "4", "5", "860"],
      ad: "",
      Index: "0",
      isShowLoading: false,
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    async getList() {
      let resulte = await getClassifyList({});
      this.categorydatas = resulte.data;
      let data = resulte.data[this.Index];
      this.ad = data.touch_catads;
    },
    async getDetalis(url) {
      this.isShowLoading = true;
      let result = await getpages(url, {});
      this.catelists = result.data;
      this.isShowLoading = false;
    },
    getIndex(data) {
      this.getDetalis("/catalog/list/" + this.getcatelists[data]);
      this.Index = data;
      this.getList();
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.getList();
    this.getDetalis("/catalog/list/858");
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.Classification {
  margin: 5rem 0 4.9rem 0;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  height: calc(100vh - 9.9rem);
  overflow-y: scroll;
  display: flex;
  background-color: #fff;
  &::-webkit-scrollbar {
    display: none;
}
}
</style>