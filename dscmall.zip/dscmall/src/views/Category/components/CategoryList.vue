<!--  -->
<template>
  <div class="CategoryList ">
   <div class="wrapper">
      <div class="Category-slide content">
      <div>
        <img :src="ad" alt="" style="width: 100%" />
      </div>
      <div class="items" v-for="(catelist, index) in catelists" :key="index">
        <div class="title">
          <span></span>
          {{ catelist.cat_name }}
        </div>
        <ul>
          <li
            v-for="(catelistchild, cat_id, index) in catelist.child"
            :key="index" 
          >
            <router-link :to="'/categorylists/'+catelistchild.cat_id">
              <img :src="catelistchild.touch_icon" alt="" />
              <p>{{ catelistchild.cat_name }}</p>
            </router-link>
          </li>
        </ul>
      </div>
    </div>
   </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
// import BScroll from "better-scroll";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    catelists: Array,
    ad: String,
  },
  data() {
    //这里存放数据
    return {
      indexs: "",
      listscroll: null,
     
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    // sceollpage() {
    //   this.listscroll = new BScroll(".wrapper", {
    //     pullUpLoad: true,
    //     scrollbar: false,
    //     pullDownRefresh: true,
    //     click: true,
    //   });
    //   this.listscroll.on("scroll", (obj) => {
    //     console.log(obj);
    //   });
    // },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    // this.sceollpage();
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.CategoryList {
  width: 79%;
  height: 100%;
  margin-left: 20%;
  // overflow-y: hidden;
  box-sizing: border-box;
  padding: 0 1rem;
  // margin-bottom: 5rem;
  .Category-slide {
    .items {
      width: 100%;
      .title {
        width: 100%;
        position: relative;
        margin: 1.1rem 0;
        height: 2.5rem;
        font-size: 1.3rem;
        text-align: center;
        line-height: 2.5rem;
        span {
          display: block;
          position: absolute;
          top: 1.3rem;
          left: 37.5%;
          width: 25%;
          height: 1px;
          background-color: #efefef;
          z-index: -1;
        }
      }
      ul {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        li {
          width: 30%;
          text-align: center;
          margin-bottom: 1rem;
          a {
            display: inline-block;
          }
          img {
            width: 80%;
          }
          p {
            width: 100%;
            height: 2rem;
            line-height: 2rem;
            font-size: 1.2rem;
            color: 777;
            margin-top: 1rem;
          }
        }
      }
    }
  }
}
</style>