<!--  -->
<template>
  <div class="mine">
    <div v-if="userInfo.token">
      <h2>个人中心</h2>
      <h1 @click="extclear">退出</h1>
    </div>
    <div v-else>
      <i class="iconfont icon-jiantou3 tick" @click="tohome"></i>
      <h3>用户登录</h3>
    <ISLogin></ISLogin>
    <div class="register">
      <router-link to="/register"> 没有账号,注册一个 </router-link>
    </div>
    </div>
    <Footer v-if="userInfo.token"></Footer>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Footer from "../../components/Footer.vue"
import ISLogin from "../Login/ISLogin";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    Footer,
    ISLogin,
  },
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {
    userInfo(){
     return this.$store.state.userInfo
    }
  },
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    extclear(){   
      this.$store.commit("extclear")
    },
    tohome(){
      this.$router.push("/home/index")
    }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.mine {
  .tick{
    position: relative;
    z-index: 999;
    top: 3rem;
    left: 2rem;
    font-size: 1.6rem;
  }
  h3 {
    margin-top: 15rem;
    z-index: 9;
    position: relative;
    text-indent: 2rem;
    font-size: 4rem;
    font-weight: 300;
  }
  .register {
    position: relative;
    z-index: 9;
    bottom: -25rem;
    text-align: center;
    a {
      color: #f44;
      text-decoration: underline;
      font-size: 1.3rem;
    }
  }
}
</style>