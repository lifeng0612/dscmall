<!--  -->
<template>
  <div class="index-page">
    <div v-infinite-scroll="loadMore" infinite-scroll-disabled="loading">
      <div class="index-header" :style="bgcolor"></div>
      <div class="index-swiper">
        <Swiper @changeColor="getColor"></Swiper>
      </div>
      <div class="hometop" v-if="shows"></div>
      <div>
        <QuickNav></QuickNav>
      </div>
      <div>
        <HomeNews></HomeNews>
      </div>
      <div class="kx-img">
        <img :src="imgsre" alt="" />
      </div>
      <div>
        <Seckill></Seckill>
      </div>
      <div>
        <SpellNav></SpellNav>
      </div>
      <div>
        <Spellgroup :spelldatas="spelldatas"></Spellgroup>
      </div>
      <div>
        <Grandstream></Grandstream>
      </div>
      <div>
        <Beauty></Beauty>
      </div>
      <div>
        <Character></Character>
      </div>
      <div>
        <Entry></Entry>
      </div>
      <div>
        <Recommend></Recommend>
      </div>
      <div>
        <div class="tabs">
          <ul>
            <li
              v-for="(tabsdata, index) in tabsdatas"
              :key="index"
              @click="chanetab(index, tabsdata.url, tabsdata.type)"
            >
              <h2>{{ tabsdata.title }}</h2>
              <h6 :class="{ hactive: hactiveindex == index }">
                {{ tabsdata.tle }}
              </h6>
            </li>
          </ul>
        </div>
        <List :listdatas="listdatas"></List>
        <h2 v-if="dilist">我也是有底线的</h2>
        <Loading v-if="isShowLoading"></Loading>
      </div>
    </div>
    <div style="height: 5rem"></div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Swiper from "@/components/Swiper";
import QuickNav from "../components/QuickNav";
import HomeNews from "../components/HomeNews";
// import ajax from "@/api/ajax";
import { getHomeList, getSpellList } from "@/api/api";
import List from "@/components/List";
import SpellNav from "../components/SpellNav";
import Spellgroup from "../components/Spellgroup";
import Grandstream from "../components/Grandstream";
import Beauty from "../components/Beauty";
import Loading from "@/components/Loading";
import Seckill from "../components/Seckill";
import Character from "../components/Character";
import Entry from "../components/Entry";
import Recommend from "../components/Recommend";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    Swiper,
    QuickNav,
    HomeNews,
    List,
    SpellNav,
    Spellgroup,
    Grandstream,
    Beauty,
    Loading,
    Seckill,
    Character,
    Entry,
    Recommend
  },
  data() {
    //这里存放数据
    return {
      imgsre: require("@/assets/img/kx.png"),
      bgcolor: {
        background: "rgb(243, 70, 70)",
      },
      colorArr: [
        {
          background: "rgb(243, 70, 70)",
        },
        {
          background: "rgb(228, 49, 36)",
        },
        {
          background: "rgb(60, 129, 255)",
        },
        {
          background: "rgb(2, 131, 121)",
        },
        {
          background: "rgb(64, 155, 255)",
        },
      ],
      listdatas: [],
      spelldatas: [],
      tabsdatas: [
        {
          id: 1,
          title: "精选",
          tle: "为你推荐",
          url: "/goods/type_list",
          type: "is_best",
        },
        {
          id: 2,
          title: "社区",
          tle: "新奇好物",
          url: "/discover/find_list",
          type: "",
        },
        {
          id: 3,
          title: "新品",
          tle: "潮流上心",
          url: "/goods/type_list",
          type: "is_new",
        },
        {
          id: 4,
          title: "热卖",
          tle: "火热爆款",
          url: "/goods/type_list",
          type: "is_hot",
        },
      ],
      hactiveindex: 0,
      url: "/goods/type_list",
      size: 10,
      page: 1,
      type: "is_best",
      isShowLoading: false,
      shows: false,
      loading: false,
      dilist:false
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {
    listdatas: function (newval, oldval) {
      if (newval.length == oldval.length) {
        this.$router.push("/Empty");
      }
    },
  },
  //方法集合
  methods: {
    getColor(data) {
      this.bgcolor = this.colorArr[data];
    },
    async getDatass() {
      this.isShowLoading = true;
      let resulte = await getSpellList({});
      this.spelldatas = resulte.data;
      this.isShowLoading = false;
    },
    async getDatas(url, page, size, type) {
      this.isShowLoading = true;
      this.loading = true;
      let result = await getHomeList(url, {
        page: page,
        size: size,
        type: type,
      });
      // console.log(result.data);
      if (result.data.length>0) {
        let resull = result.data;
        this.listdatas = this.listdatas.concat(resull);
        this.isShowLoading = false;
        this.loading = false;
      } else if (result.data == undefined) {
        this.isShowLoading = false;
        alert("数据加载失败");
      }else{
        console.log(123);
        this.isShowLoading = false;
        this.dilist = true
      }
    },
    chanetab(index, url, type) {
      this.page = 1;
      this.listdatas = [];
      this.hactiveindex = index;
      this.url = url;
      this.type = type;
      this.getDatas(url, this.page, this.size, type);
    },
    loadMore() {
      this.getDatas(this.url, this.page, this.size, this.type);
      this.page++;
    },
    handleScroll() {
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;
      if (scrollTop > 160) {
        this.shows = true;
      } else if (scrollTop < 160) {
        this.shows = false;
      }
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.getDatass();
    // this.getDatas(this.url, this.page, this.size, this.type);
    window.addEventListener("scroll", this.handleScroll);
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll);
  }, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.index-page {
  .index-header {
    height: 14.8rem;
    background: red;
    border-bottom-right-radius: 2rem;
    border-bottom-left-radius: 2rem;
    transition: all 0.3s ease;
  }
  .index-swiper {
    position: relative;
    top: -5rem;
  }
  .hometop {
    width: 100%;
    height: 8.8rem;
    background: red;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 96;
  }
  .kx-img {
    width: 100%;
    margin-left: 10px;
    margin-right: 10px;
    width: calc(100% - 20px);
    position: relative;
    top: -3rem;
    img {
      width: 100%;
    }
  }
  .tabs {
    margin-left: 10px;
    margin-right: 10px;
    ul {
      width: 100%;
      height: 6rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      li {
        width: 25%;
        text-align: center;
        border-right: 1px solid #ccc;
        &:last-child {
          border-right: none;
        }
        h2 {
          font-size: 1.6rem;
          margin-bottom: 0.5rem;
          height: 3rem;
    text-align: center;
    line-height: 3rem;
        }
        h6 {
          font-weight: normal;
          color: #666;
          height: 2rem;
          line-height: 2rem;
        }
        .hactive {
          background-color: red;
          width: 80%;
          margin-left: 10%;
          color: #fff;
          border-radius: 10px;
        }
      }
    }
  }
  h2{
    height: 4.4rem;
    width: 100%;
    line-height: 6.4rem;
    text-align: center;
    margin-bottom: 1rem;
    font-size: 1.6rem;
    color: #666;
    font-weight: normal;
  }
}
</style>