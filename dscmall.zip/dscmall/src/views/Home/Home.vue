<!--  -->
<template>
  <div
    class="home-page"
    v-infinite-scroll="loadMore"
    infinite-scroll-disabled="loading"
  >
    <HomeHeader></HomeHeader>
    <div class="navbar">
      <ly-tab
        v-model="selectedId"
        :items="items"
        :options="options"
        @change="changeTab"
      ></ly-tab>
      <div class="category-btn" @click="skiphome">
        <i class="iconfont icon-fenlei"></i>
        <span>分类</span>
      </div>
    </div>
    <div class="bg" v-if="this.$route.path != '/home/index'"></div>
    <div>
      <router-view
        :getdatalists="getdatalists"
        :getdatafys="getdatafys"
      ></router-view>
    </div>
    <div class="other_List">
      <ul>
        <li v-for="(homelist, index) in homelistdata" :key="index">
          <router-link :to="'/goodsdetail/' + homelist.goods_id">
            <img :src="homelist.goods_thumb" alt="" />
            <div class="list">
              <div class="List_title">{{ homelist.goods_name }}</div>
              <div class="List_price">{{ homelist.shop_price }}</div>
            </div>
          </router-link>
        </li>
      </ul>
    </div>
    <!-- <div style="height:5rem"></div> -->
    <Loading v-if="isShowLoading"></Loading>
    <Footer></Footer>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Footer from "../../components/Footer.vue";
//引入首页头部
import HomeHeader from "./components/HomeHeader";
// import Axios from "axios"
import { getHome } from "@/api/api";
import Loading from "@/components/Loading";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    Footer,
    HomeHeader,
    Loading,
  },
  data() {
    //这里存放数据
    return {
      getdatalists: [],
      getdatafys: [],
      isShowLoading: false,
      selectedId: 0,
      pageee: false,
      items: [
        { label: "首页" },
        { label: "家用电器" },
        { label: "男装女装" },
        { label: "鞋靴箱包" },
        { label: "手机数码" },
        { label: "电脑办公" },
        { label: "家居家纺" },
        { label: "个人化妆" },
      ],
      options: {
        activeColor: "#fff",
        // 可在这里指定labelKey为你数据里文字对应的字段名
      },
      routerDatas: [
        "/home/index",
        "/home/household",
        "/home/clothing",
        "/home/shoebag",
        "/home/mobilephones",
        "/home/computer",
        "/home/hometextiles",
        "/home/personalmakeup",
      ],
      getDatas: ["1.1", "858", "6", "8", "3", "4", "5", "860"],
      sort: "goods_id",
      order: "desc",
      size: "10",
      page: "1",
      cat_id: "858",
    };
  },
  //监听属性 类似于data概念
  computed: {
    homelistdata() {
      return this.$store.state.homelistdata;
    },
  },
  //监控data中的数据变化
  watch: {
    cat_id() {
      this.$store.state.homelistdata = [];
    },
  },
  //方法集合
  methods: {
    changeTab(item, index) {
      this.$router.push(this.routerDatas[index]);
      this.getHomes(this.getDatas[index]);
      this.cat_id = this.getDatas[index];
      this.page = "1"
      this.reqdata();
      this.pageee = true;
    },
    skiphome() {
      this.$router.push("/category");
    },
    async getHomes(cat_id) {
      this.isShowLoading = true;
      let result = await getHome({
        cat_id: cat_id,
      });
      if (result.data) {
        this.getdatalists = result.data.category;
        this.getdatafys = result.data.brand;
        this.isShowLoading = false;
      } else if (result.data == undefined) {
        this.isShowLoading = false;
        alert("数据加载失败");
      }
    },
    reqdata() {
      let params = {
        url: "/catalog/goodslist",
        params: {
          cat_id: this.cat_id,
          sort: this.sort,
          order: this.order,
          size: this.size,
          page: this.page,
        },
        type: "post",
      };
      this.$store.dispatch("acthangeotherlist", params);
    },
    loadMore() {
       if (this.pageee) {
          this.page = "2";
        }
      if (this.$route.path == "/home/index") {
        return;
      } else {
        this.pageee = false
        this.isShowLoading = true;
        this.reqdata();
        this.page++;
        setTimeout(() => {
          this.isShowLoading = false;
        }, 500);
      }
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.routerDatas.forEach((item, index) => {
      if (item == this.$route.path) {
        this.selectedId = index;
      }
    });
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.home-page {
  .bg {
    width: 100%;
    left: 0;
    top: 0;
    height: 8.8rem;
    background: red;
    position: fixed;
    z-index: 9;
  }
  .navbar {
    position: fixed;
    width: 100%;
    left: 0;
    top: 4.4rem;
    z-index: 99;
    background-color: transparent;
    display: flex;
    .ly-tab {
      width: 85%;
      .ly-tabbar {
        height: 4.4rem;
        background-color: transparent;
        border-bottom: none;
        box-shadow: none;
        .ly-tab-list {
          a {
            color: #fff;
          }
        }
      }
    }
    .category-btn {
      width: 15%;
      height: 4.4rem;
      text-align: center;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      i {
        font-size: 2rem;
        box-shadow: -6px 0 4px -4px rgba(0, 0, 0, 0.4);
      }
    }
  }
  .other_List {
    width: calc(100% - 2rem);
    margin-left: 1rem;
    margin-bottom: 5rem;

    ul {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      li {
        box-sizing: border-box;
        width: 50%;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        border-radius: 1rem;
        margin-bottom: 0.5rem;
        &:nth-child(2n-1) {
          padding-right: 0.3rem;
        }
        &:nth-child(2n) {
          padding-left: 0.3rem;
        }
        img {
          width: 100%;
          height: 17.8rem;
          border-top-left-radius: 1rem;
          border-top-right-radius: 1rem;
        }
        .list {
          background-color: #fff;
          .List_title {
            font-size: 1.4rem;
            padding: 0.8rem;
            height: 3.8rem;
            line-height: 2.2rem;
            overflow: hidden;
            -webkit-box-orient: vertical;
            display: -webkit-box;
            text-overflow: ellipsis;
            -webkit-line-clamp: 2;
          }
          .List_price {
            padding: 0.6rem 0;
            color: #f44;
            font-weight: 700;
            font-size: 1.4rem;
            text-align: center;
            margin-bottom: 0.6rem;
            &::before {
              content: "¥";
              font-size: 1.2rem;
              color: #f44;
            }
          }
        }
      }
    }
  }
}
</style>