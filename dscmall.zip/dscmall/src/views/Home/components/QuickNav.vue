<!--  -->
<template>
  <div class="quick-nav">
    <mt-swipe :auto="0" :continuous="false">
      <mt-swipe-item v-for="(item, index) in quickNavDatas" :key="index">
        <ul>
          <li v-for="(value, index) in item" :key="index">
            <img :src="value.imgsrc" alt="" />
            <span>{{ value.title }}</span>
          </li>
        </ul>
      </mt-swipe-item>
    </mt-swipe>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      quickNavDatas: [
        [
          {
            id: 1,
            imgsrc: require("@/assets/img/r1.png"),
            title: "潮流服饰",
          },
          {
            id: 2,
            imgsrc: require("@/assets/img/r2.png"),
            title: "鞋包配饰",
          },
          {
            id: 3,
            imgsrc: require("@/assets/img/r3.png"),
            title: "美容护肤",
          },
          {
            id: 4,
            imgsrc: require("@/assets/img/r4.png"),
            title: "母婴儿童",
          },
          {
            id: 5,
            imgsrc: require("@/assets/img/r5.png"),
            title: "手机数码",
          },
          {
            id: 6,
            imgsrc: require("@/assets/img/r6.png"),
            title: "微社区",
          },
          {
            id: 7,
            imgsrc: require("@/assets/img/r7.gif"),
            title: "拼团",
          },
          {
            id: 8,
            imgsrc: require("@/assets/img/r8.gif"),
            title: "预售",
          },
          {
            id: 9,
            imgsrc: require("@/assets/img/r9.png"),
            title: "拍卖",
          },
          {
            id: 10,
            imgsrc: require("@/assets/img/r10.gif"),
            title: "超值礼包",
          },
        ],
        [
          {
            id: 11,
            imgsrc: require("@/assets/img/r2-1.png"),
            title: "家居装饰",
          },
          {
            id: 12,
            imgsrc: require("@/assets/img/r2-2.png"),
            title: "休闲零食",
          },
          {
            id: 13,
            imgsrc: require("@/assets/img/r2-3.png"),
            title: "水果生鲜",
          },
          {
            id: 14,
            imgsrc: require("@/assets/img/r2-4.png"),
            title: "萌宠",
          },
          {
            id: 15,
            imgsrc: require("@/assets/img/r2-5.png"),
            title: "大家电",
          },
          {
            id: 16,
            imgsrc: require("@/assets/img/r2-6.png"),
            title: "店铺街",
          },
          {
            id: 17,
            imgsrc: require("@/assets/img/r2-7.png"),
            title: "品牌特卖",
          },
          {
            id: 18,
            imgsrc: require("@/assets/img/r2-8.png"),
            title: "天天特价",
          },
          {
            id: 19,
            imgsrc: require("@/assets/img/r2-9.png"),
            title: "限时团购",
          },
          {
            id: 20,
            imgsrc: require("@/assets/img/r2-10.png"),
            title: "积分商城",
          },
        ],
        [
          {
            id: 21,
            imgsrc: require("@/assets/img/r3-1.png"),
            title: "限时秒杀",
          },
          {
            id: 22,
            imgsrc: require("@/assets/img/r3-2.png"),
            title: "到家O2O",
          },
          {
            id: 23,
            imgsrc: require("@/assets/img/r3-3.png"),
            title: "拍卖",
          },
          {
            id: 24,
            imgsrc: require("@/assets/img/r3-4.png"),
            title: "促销活动",
          },
          {
            id: 25,
            imgsrc: require("@/assets/img/r3-5.png"),
            title: "酒水饮料",
          },
          {
            id: 26,
            imgsrc: require("@/assets/img/r3-6.png"),
            title: "母婴专区",
          },
          {
            id: 27,
            imgsrc: require("@/assets/img/r3-7.png"),
            title: "图文文娱",
          },
          {
            id: 28,
            imgsrc: require("@/assets/img/r3-8.png"),
            title: "中西乐器",
          },
          {
            id: 29,
            imgsrc: require("@/assets/img/r3-9.png"),
            title: "花卉绿植",
          },
          {
            id: 30,
            imgsrc: require("@/assets/img/r3-10.png"),
            title: "香水香氛",
          },
        ],
      ],
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.quick-nav {
  height: 21rem;
  position: relative;
  top: -4rem;
  margin-left: 10px;
  margin-right: 10px;
  background-color: #fff;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  ul {
    height: 18rem;
    display: flex;
    flex-wrap: wrap;
    li {
      height: 9rem;
      width: 20%;
      text-align: center;
      img {
        width: 7rem;
        height: 7rem;
      }
    }
  }
  .mint-swipe-indicator {
    opacity: 1;
    width: 16px;
    float: left;
    margin: 0;
    border-radius: 0;
    background: rgba(255, 0, 0, 0.5);
  }
  .mint-swipe-indicator.is-active {
    background: red;
  }
  .mint-swipe-indicators {
    bottom: 5px;
    height: 5px;
    border-radius: 10px;
    overflow: hidden;
  }
}
</style>