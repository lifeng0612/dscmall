<!--  -->
<template>
  <div class="recommend">
    <div class="rectitle">
      <h2>店铺推荐</h2>
      <span>更多品质好点</span>
      <div class="resi">
        <i class="iconfont icon-jiantou2"></i>
      </div>
    </div>
    <div class="resiper">
      <div class="swiper-container">
        <div class="swiper-wrapper" style="top: 0;">
          <div
            class="swiper-slide"
            v-for="resList in resLists"
            :key="resList.id"
          >
            <img :src="resList.imgses" alt="" />
            <div class="title">
              <img :src="resList.imgse" alt="" />
              <span>{{ resList.title }}</span>
            </div>
            <p>
              共计<span>{{ resList.num }}</span
              >件商品
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="itemlist">
        <img src="@/assets/img/t-u1.png" alt="">
        <img src="@/assets/img/t-u2.png" alt="">
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Swiper from "swiper";
import "../../../styles/swiper-bundle.min.css";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      resLists: [
        {
          id: 1,
          imgses: require("@/assets/img/tu1.jpg"),
          imgse: require("@/assets/img/tu-1.jpg"),
          title: "普陀区 - 万卓旗舰店",
          num: 13,
        },
        {
          id: 2,
          imgses: require("@/assets/img/tu2.jpg"),
          imgse: require("@/assets/img/tu-2.jpg"),
          title: "创造旗舰店",
          num: 62,
        },
        {
          id: 3,
          imgses: require("@/assets/img/tu3.png"),
          imgse: require("@/assets/img/tu-3.jpg"),
          title: "大商创旗舰店",
          num: 32,
        },
        {
          id: 4,
          imgses: require("@/assets/img/tu4.jpg"),
          imgse: require("@/assets/img/tu-4.jpg"),
          title: "绿联",
          num: 8,
        },
        {
          id: 5,
          imgses: require("@/assets/img/tu5.jpg"),
          imgse: require("@/assets/img/tu-5.jpg"),
          title: "火影旗舰店",
          num: 9,
        },
        {
          id: 6,
          imgses: require("@/assets/img/tu6.jpg"),
          imgse: require("@/assets/img/tu-6.jpg"),
          title: "全友家私",
          num: 10,
        },
        {
          id: 7,
          imgses: require("@/assets/img/tu7.jpg"),
          imgse: require("@/assets/img/tu-7.jpg"),
          title: "三只松鼠",
          num: 18,
        },
        {
          id: 8,
          imgses: require("@/assets/img/tu8.jpg"),
          imgse: require("@/assets/img/tu-8.jpg"),
          title: "美宝莲",
          num: 10,
        },
        {
          id: 9,
          imgses: require("@/assets/img/tu9.jpg"),
          imgse: require("@/assets/img/tu-9.jpg"),
          title: "成人旗舰店",
          num: 9,
        },
        {
          id: 10,
          imgses: require("@/assets/img/tu10.jpg"),
          imgse: require("@/assets/img/tu-10.jpg"),
          title: "韩都衣舍",
          num: 9,
        },
      ],
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    new Swiper(".swiper-container", {
      slidesPerView: 3,
      spaceBetween: 6,
      observer: true, //修改swiper自己或子元素时，自动初始化swiper
      observeParents: true, //修改swiper的父元素时，自动初始化swiper
    });
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.recommend {
  width: calc(100% - 20px);
  margin-left: 10px;
  margin-right: 10px;
  background-color: #fff;
  border-radius: 10px;
  overflow: hidden;
  margin-bottom: 1rem;
  .rectitle {
    padding: 1.2rem;
    display: flex;
    align-items: center;
    h2 {
      font-size: 1.8rem;
      margin-right: 1rem;
    }
    span {
      font-size: 1.4rem;
      color: #888;
    }
    .resi {
      width: 4%;
      border: 1px solid red;
      border-radius: 50%;
      margin-left: 0.3rem;
      display: flex;
      justify-content: center;
      align-items: center;
      i {
        color: red;
        font-size: 1.2rem;
        padding-top: 1px;
        padding-left: 2px;
      }
    }
  }
  .resiper {
    width: 100%;
    margin-bottom: 1rem;
    .swiper-container {
      border-top: none;
      .swiper-slide {
        background-color: #f6f6f6;
        border-radius: 1rem;
        overflow: hidden;
        img {
          width: 100%;
          height: 8.5rem;
        }
        .title {
          padding: 1.2rem 0.5rem .2rem;
          text-align: center;
          box-sizing: border-box;
          width: 100%;
          position: relative;
          img {
            width: 3.5rem;
            height: 3.5rem;
            border-radius: 50%;
            position: absolute;
            top: -2.3rem;
            left: 3.8rem;
          }
          span {
            display: inline-block;
            width: 100%;
            font-size: 1.3rem;
            color: #000;
            line-height: 1.7rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
        p{
            font-size: 1.2rem;
            color: #888;
            margin-bottom: 2rem;
            span{
                margin-left: 0.2rem;
                margin-right: 0.2rem;
                color: #333;
            }
        }
        &:first-child {
          margin-left: 1rem;
        }
      }
    }
  }
  .itemlist{
      width: calc(100% -12px);
      margin-left: 6px;
      margin-right: 6px;
      display: flex;
      justify-content: space-around;
      margin-bottom: 1rem;
      img{
          width: 48%;
      }
  }
}
</style>