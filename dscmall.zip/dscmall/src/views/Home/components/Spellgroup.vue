<!--  -->
<template>
  <div class="spell-group">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div
          class="swiper-slide"
          v-for="spelldata in spelldatas"
          :key="spelldata.goods_id"
        >
         <router-link :to="'/goodsdetail/'+ spelldata.goods_id">
            <img :src="spelldata.goods_thumb" alt="" />
          <div class="sepll-info">
            <div class="info-title">{{ spelldata.goods_name }}</div>
            <div class="info-pric">
              <img src="@/assets/img/pt.png" alt="" />
              <span>{{ spelldata.team_price_formated }}</span>
            </div>
            <del>{{ spelldata.shop_price_formated }}</del>
          </div>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Swiper from "swiper";
import "../../../styles/swiper-bundle.min.css";

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: {
    spelldatas: Array,
  },
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    // tolink(){
    //   this.$router.push('/goodsdetail/'+ this.spelldatas.goods_id)
    // }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    new Swiper(".swiper-container", {
      slidesPerView: 3,
      spaceBetween: 6,
      observer: true, //修改swiper自己或子元素时，自动初始化swiper
      observeParents: true, //修改swiper的父元素时，自动初始化swiper
    });
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.spell-group {
  padding: 0 0 0 1rem;
  box-sizing: border-box;
  margin-left: 10px;
  margin-right: 10px;
  width: calc(100% - 20px);
  height: 23rem;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
  background-color: #fff;
  position: relative;
  top: -2rem;
}
.swiper-container {
  border-top: 1px solid #ccc;
  width: 100%;
  height: 100%;
  border-bottom-right-radius: 10px;
}
.swiper-wrapper {
  top: 2rem;
}
.swiper-slide {
  text-align: center;
  font-size: 18px;
  background: #fff;
  img {
    width: 100%;
  }
  .sepll-info {
    padding: 1rem 0.5rem;
    text-align: center;
    .info-title {
      width: 100%;
      font-size: 1.3rem;
      color: #000;
      height: 2rem;
      line-height: 2rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .info-pric {
      margin-top: 0.5rem;
      img {
        width: 2rem;
        height: 2rem;
        display: inline-block;
        margin-left: -0.5rem;
        vertical-align: bottom;
      }
      span {
        font-size: 1.5rem;
        font-weight: 700;
        color: rgb(242, 14, 40);
        margin-left: .3rem;
      }
    }
    del {
      margin-top: 0.5rem;
      display: block;
      font-size: 1.05rem;
      color: rgb(136, 136, 136);
    }
  }
}
</style>