<!--  -->
<template>
  <div class="spell">
    <div class="spell-nav">
      <h3>拼团专区</h3>
      <span>拼着买更实惠</span>
      <div class="spelli">
        <i class="iconfont icon-jiantou2"></i>
      </div>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {};
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.spell {
  width: 100%;
  box-sizing: border-box;
  margin-left: 10px;
  margin-right: 10px;
  width: calc(100% - 20px);
  background-color: #fff;
  padding: 0 1rem;
  position: relative;
  top: -2rem;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
  .spell-nav {
    display: flex;
    align-items: center;
    padding: 1.5rem 1rem;
    h3{
        font-size: 1.8rem;
        color: #000;
        margin: 0 1rem 0 .5rem;
    }
    span{
            font-size: 1.4rem;
            color:#888;
        }
        .spelli{
          width: 5%;
         padding: 2px;
          border-radius: 50%;
          border: 1px solid red;
          margin-left: 5px;
          i{
            color: #f20d23;
            font-size: 1.4rem;
            padding-left: 2px;
        }
        }
        
  }
}
</style>