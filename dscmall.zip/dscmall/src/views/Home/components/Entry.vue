<!--  -->
<template>
  <div class="entry">
    <div class="chara_img">
      <img src="@/assets/img/qs.jpeg" alt="" />
    </div>
    <div class="charatitle">
      <ul>
        <li v-for="charaList in charaLists" :key="charaList.id">
          <img :src="charaList.imgses" alt="" />
          <div class="title">
            <p>{{ charaList.title }}</p>
          </div>
          <div class="price">
            <span>{{ charaList.price }}</span>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      charaLists: [
        {
          id: 1,
          imgses: require("@/assets/img/qs1.jpg"),
          title:
            "DR DARRY RING心月套链钻石吊坠月亮心形镶钻项链正品会员专享",
          price: "¥2799.00",
        },
        {
          id: 2,
          imgses: require("@/assets/img/qs2.jpg"),
          title:
            "DR FLOWER LOVE系列玫瑰耳饰钻石群镶耳钉白红黄18K金浪漫送女友",
          price: "¥4399.00",
        },
        {
          id: 3,
          imgses: require("@/assets/img/qs3.jpg"),
          title:
            "DR WITH YOU系列挚爱相随粉钻求婚钻戒钻石戒指下单请咨询客服",
          price: "¥37179.00",
        },
        {
          id: 4,
          imgses: require("@/assets/img/qs4.jpg"),
          title:
            "DR SWEETIE系列心连心套链心形钻石项链吊坠白红黄18K金会员专享",
          price: "¥4599.00",
        },
        {
          id: 5,
          imgses: require("@/assets/img/qs5.jpg"),
          title:
            "casio旗舰店SHE-4529防水女士手表钢表带卡西欧官网SHEEN官方正品",
          price: "¥1090.00",
        },
        {
          id: 6,
          imgses: require("@/assets/img/qs6.jpg"),
          title:
            "DR TRUE LOVE系列情圆一生求婚钻戒结婚钻石戒指女戒白18K金",
          price: "¥7059.00",
        },
      ],
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.entry {
  width: calc(100% - 20px);
  margin-left: 10px;
  margin-right: 10px;
  border-radius: 10px;
  overflow: hidden;
  background-color: rgb(44, 77, 105);
  margin-bottom: 1rem;
  .chara_img {
    width: 100%;
    img {
      width: 100%;
    }
  }
  .charatitle {
    width: 100%;
   margin-top: -8rem;
   margin-bottom: 1.6rem;
    ul {
      width: calc(100% - 7%);
      margin-left: 3.5%;
      margin-right: 3.5%;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li {
        width: 32%;
        background-color: #fff;
        border-radius: 1rem;
        overflow: hidden;
        margin-bottom: 0.6rem;
        img {
          width: 100%;
        }
        .title {
          padding: 0.5rem 0.8rem;
          p {
            width: 100%;
            font-size: 1.3rem;
            color: #000;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }
        }
        .price{
            padding: 0 .8rem;
            margin-bottom: .3rem;
            span{
                font-size: 15px;
                font-weight: 700;
                color: rgb(242, 14, 40);
            }
        }
      }
    }
  }
}
</style>