<!--  -->
<template>
  <div class="Beauty">
    <div class="grand-img">
      <img src="@/assets/img/mz.jpeg" alt="" />
    </div>
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div
          class="swiper-slide"
          v-for="granData in granDatas"
          :key="granData.id"
        >
          <img :src="granData.imgseg" alt="" />
          <div class="lists-title">
            <div>{{ granData.title }}</div>
          </div>
          <div class="lists-price">
            <span>{{ granData.price }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Swiper from "swiper";
import "../../../styles/swiper-bundle.min.css";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      granDatas: [
        {
          id: 1,
          imgseg: require("@/assets/img/mz1.jpg"),
          title:
            "【七夕礼物】雅诗兰黛倾慕晶彩唇膏 保湿补水 滋润防水 130枫叶色",
          price: "¥280.00",
        },
        {
          id: 2,
          imgseg: require("@/assets/img/mz2.jpg"),
          title:
            "雅诗兰黛大牌蜜粉 臻透无痕蜜粉10g 定妆遮瑕",
          price: "¥500.00",
        },
        {
          id: 3,
          imgseg: require("@/assets/img/mz3.jpg"),
          title: "雅诗兰黛沁水双层气垫BB霜  保湿遮瑕 水润奶油肌裸妆 官方正品",
          price: "¥590.00",
        },
        {
          id: 4,
          imgseg: require("@/assets/img/mz4.jpg"),
          title:
            "雅诗兰黛肌透修护密集精华眼膜套装 4/8片装 提拉紧致 淡化细纹",
          price: "¥300.00",
        },
        {
          id: 5,
          imgseg: require("@/assets/img/mz5.jpg"),
          title:
            "雅诗兰黛 花漾倾慕腮红渐变腮红 裸妆自然提亮肤色立体塑型修容",
          price: "¥450.00",
        },
        {
          id: 6,
          imgseg: require("@/assets/img/mz6.jpg"),
          title:
            "雅诗兰黛面膜 小棕瓶双层面膜4片/8片 补水保湿 密集修护",
          price: "¥680.00",
        },
      ],
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {},
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    new Swiper(".swiper-container", {
      slidesPerView: 3,
      spaceBetween: 6,
      observer: true, //修改swiper自己或子元素时，自动初始化swiper
      observeParents: true, //修改swiper的父元素时，自动初始化swiper
    });
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.Beauty {
  width: 100%;
  margin-left: 10px;
  margin-right: 10px;
  width: calc(100% - 20px);
  position: relative;
  top: -1rem;
  border-radius: 10px;
  overflow: hidden;
  margin-top: 1rem;
  // margin-bottom: 30rem;
  .grand-img {
    width: 100%;
    border-radius: 10px;
    overflow: hidden;
    img {
      width: 100%;
      border-radius: 10px;
    }
  }
  .swiper-container {
    border: none !important;
    width: 100%;
    border-bottom-right-radius: 10px;
    margin-top: -8.5rem;
    margin-left: 6px;
  }
  .swiper-wrapper {
    top: 0rem !important;
    .swiper-slide {
      border-radius: 10px;
      overflow: hidden;
      img{
        width: 100%;
      }
      .lists-title {
        padding: 1rem 0.5rem 0.2rem;
        text-align: left;
        div {
          width: 100%;
          font-size: 1.3rem;
          color: #000;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      }
      .lists-price{
        width: 100%;
        text-align: left;
        margin-bottom: 6px;
        span{
          margin-left: 5px;
          display: inline-block;
          font-size: 15px;
          font-weight: 700;
          color: rgb(242, 14, 40);
          text-align: left;
        }
      }
    }
  }
}
</style>