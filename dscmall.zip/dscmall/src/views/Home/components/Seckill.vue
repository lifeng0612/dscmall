<!--  -->
<template>
  <div class="seckill">
    <div class="top">
      <div class="top-img">
        <img src="@/assets/img/sh.png" alt="" />
      </div>
      <div class="top-sh">
        <p v-if="!(this.newtiem == 0)">
          距离结束还剩:
          <span>{{ hours >= 10 ? hours : "0" + hours }}</span
          ><em>:</em><span>{{ minutes >= 10 ? minutes : "0" + minutes }}</span
          ><em>:</em><span>{{ seconds >= 10 ? seconds : "0" + seconds }}</span>
        </p>
        <p v-else style="color: #999">距离结束还剩:&nbsp;秒杀已结束</p>
      </div>
    </div>
    <div class="title">
      <ul>
        <li
          v-for="(timeList, index) in timeLists"
          :key="timeList.id"
          :class="{ active: activeindex == index }"
          @click="changetab(index, timeList.id)"
        >
          <h4>{{ timeList.title }}</h4>
          <h3>{{ timeList.status ? "抢购中" : "即将开始" }}</h3>
        </li>
      </ul>
    </div>
    <div class="sh-swiper">
      <div class="swiper-container" style="border-top: none">
        <div class="swiper-wrapper">
          <div
            class="swiper-slide"
            v-for="seclillList in seclillLists"
            :key="seclillList.id"
          >
            <router-link :to="'/goodsdetail/'+seclillList.goods_id">
              <img :src="seclillList.goods_thumb" alt="" />
            <div class="seckill-info">
              <div class="info-title">{{ seclillList.goods_name }}</div>
              <div class="info-pric">
                <span>{{ seclillList.sec_price_formated }}</span>
              </div>
              <del>{{ seclillList.market_price_formated }}</del>
            </div>
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <div class="seckillmore">
      <span>查看更多秒杀商品</span>
      <i class="iconfont icon-jiantou2"></i>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { getSeckill } from "@/api/api";
import Swiper from "swiper";
import "../../../styles/swiper-bundle.min.css";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      seclillLists: [],
      timeLists: [],
      activeindex: 0,
      id: null,
      hours: "00",
      minutes: "00",
      seconds: "00",
      Timer: null,
      newtiem: null,
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {
    timeLists: function (newval) {
      if (!newval.tomorrow) {
        this.Timer = setInterval(() => {
          let enter = newval[0];
          let times = enter.frist_end_time;
          let time = +new Date(times);
          let nowtime = +new Date();
          this.newtiem = (time - nowtime) / 1000;
          this.hours = Math.floor((this.newtiem / 60 / 60) % 24);
          this.minutes = Math.floor((this.newtiem / 60) % 60);
          this.seconds = Math.floor(this.newtiem % 60);
        }, 4);
      }
    },
  },
  //方法集合
  methods: {
    async getdatalist(url, id, tomorrow) {
      let result = await getSeckill(url, {
        id: id,
        tomorrow: tomorrow,
      });
      // console.log(result.data);
      this.seclillLists = result.data.seckill_list;
      this.timeLists = result.data.time_list;
    },
    changetab(index, id) {
      this.activeindex = index;
      this.id = id;
      this.getdatalist("/visual/visual_seckill", this.id, 0);
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
    this.getdatalist("/visual/visual_seckill", this.id, 0);
    new Swiper(".swiper-container", {
      slidesPerView: 3,
      spaceBetween: 6,
      observer: true, //修改swiper自己或子元素时，自动初始化swiper
      observeParents: true, //修改swiper的父元素时，自动初始化swiper
    });
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {
    clearInterval(this.Timer);
  }, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.seckill {
  width: calc(100% - 20px);
  margin-left: 10px;
  margin-right: 10px;
  background-color: #fff;
  border-radius: 10px;
  margin-bottom: 1rem;
  position: relative;
  top: -2rem;
  .top {
    width: 100%;
    box-sizing: border-box;
    padding: 1.2rem 1rem;
    display: flex;
    align-items: center;
    .top-img {
      width: 35%;
      img {
        width: 100%;
      }
    }
    .top-sh {
      width: 63%;
      text-align: right;
      p {
        font-size: 1.4rem;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        span {
        height: 1.5rem;
        line-height: 1.5rem;
          display: inline-block;
          width: 2rem;
          text-align: center;
          background-color: red;
          border-radius: 3px;
          color: #fff;
          font-size: 1.2rem;
          margin-right: 0.3rem;
          margin-left: 3px;
          padding-top: 2px;
          padding-bottom: 2px;
        }
        em {
          font-style: normal;
          margin-left: 0.2rem;
        }
      }
    }
  }
  .title {
    width: 100%;
    ul {
      width: 100%;
      padding: 0.2rem 0;
      display: flex;
      justify-content: center;
      align-items: center;
      li {
        width: 25%;
        height: 5rem;
        color: #999;
        border-bottom: 1px solid #ccc;
        display: flex;
        flex-direction: column;
        justify-content: center;
        h4 {
          font-weight: normal;
          font-size: 1.4rem;
          text-align: center;
        }
        h3 {
          font-weight: normal;
          font-size: 1.2rem;
          text-align: center;
        }
      }
      .active {
        border-bottom: 1px solid red;
        h4 {
          font-size: 1.8rem;
          color: red;
        }
        h3 {
          font-size: 1.4rem;
          color: red;
        }
      }
    }
  }
  .sh-swiper {
    margin-top: -2px;
    margin-left: 1rem;
    .swiper-slide {
      background-color: #fff;
      img {
        width: 100%;
      }
      .seckill-info {
        padding: 1rem 0.5rem;
        .info-title {
          font-size: 1.3rem;
          color: #000;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .info-pric {
          width: 100%;
          span {
            margin-right: 1.8rem;
            font-size: 15px;
            font-weight: 500;
            display: inline-block;
            color: rgb(242, 14, 40);
          }
        }
        del {
          font-size: 10.5px;
          display: inline-block;
          color: rgb(136, 136, 136);
          margin-bottom: 1rem;
          padding-right: 1.8rem;
          position: relative;
          top: -0.5rem;
        }
      }
    }
  }
  .seckillmore {
    width: 100%;
    padding: 1.5rem 0;
    display: flex;
    justify-content: center;
    align-items: center;
    span {
      font-size: 1.6rem;
      font-size: 7000;
      color: #000;
      margin-right: 0.5rem;
    }
    i {
      font-size: 1.6rem;
      font-size: 700;
      color: #000;
    }
  }
}
</style>