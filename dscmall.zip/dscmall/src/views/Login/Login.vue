<!--  -->
<template>
  <div class="login">
    <div class="back">
      <span class="iconfont icon-jiantou3" onclick="window.history.back()"></span>
    </div>
    <div class="lgoin_img">
      <!-- <img :src="logImg" alt="" /> -->
      <h3 v-if="activeId==0">短信验证码登录</h3>
      <h3 v-if="activeId==1">用户名登录</h3>
    </div>
    <div class="tologin_tabs">
      <div class="btn" :class="{active:activeId==0}" @click="toactive(0)">短信登录</div>
      <div class="btn" :class="{active:activeId==1}" @click="toactive(1)">账号登录</div>
    </div>
    <div class="to_item">
      <!-- 短信登录 -->
      <div class="item_content" v-if="activeId==0">
        <div class="item_input">
            <i class="iconfont icon-baozheng"></i>
          <input type="text" placeholder="请输入验证码" name="captcha" v-model="captcha"/>
         <img src="http://192.168.1.14:3000/adminapi/getcaptcha" alt="" @click="capcthaImg" ref="captcha">
        </div>
        <div class="item_input">
            <i class="iconfont icon-wode"></i>
          <input type="text" placeholder="请输入手机号" maxlength="11" name="phone" v-model="phone"/>
          <button v-if="!num" @click="getchpatchacode">{{textcode}}</button>
          <button v-else>重新发送（{{num}}）S</button>
        </div>
        <div class="item_input">
            <i class="iconfont icon-yaochi" style="font-size:1.8rem"></i>
          <input type="text" placeholder="请输入短信验证码" style="width:100%" name="code"/>
        </div>
        <div class="reglog" @click="captchalogin">立即登录</div>
      </div>
      <!-- 账号登录 -->
       <div class="item_content" v-if="activeId==1">
        <div class="item_input">
            <i class="iconfont icon-baozheng"></i>
          <input type="text" placeholder="请输入验证码" name="captcha" v-model="captcha"/>
          <img src="http://192.168.1.14:3000/adminapi/getcaptcha" alt="" @click="capcthaImg" ref="captcha">
        </div>
        <div class="item_input">
            <i class="iconfont icon-wode"></i>
          <input type="text" placeholder="请输入用户名" style="width:100%" name="user_name" v-model="user_name"/>
        </div>
        <div class="item_input tabs_input">
            <i class="iconfont icon-icon-pwd" style="font-size:1.2rem"></i>
          <i class="iconfont icon-yincang" v-if="iconshow" @click="iconpaw"></i>
          <i class="iconfont icon-xianshi" v-if="!iconshow" @click="iconpaw"></i>
          <input type="password" v-if="iconshow" placeholder="请输入密码" name="login_password" v-model="login_password" style="width:100%"/>
          <input type="text" v-if="!iconshow" placeholder="请输入密码" name="login_password" v-model="login_password" style="width:100%"/>
        </div>
        <div class="reglog" @click="getloginName">立即登录</div>
      </div>
    </div>
    <div class="register">
        <router-link to="/register">
            没有账号,注册一个
        </router-link>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { Toast } from 'mint-ui';
import {getphonecode,getphonecodelogin,getuserNamelogin} from "@/api/api"
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      logImg: require("@/assets/logo.png"),
      activeId:0,
      iconshow:true,
      textcode:"获取验证码",
      timer:null,
      num:0,
      phone:"",
      mes:"手机号格式不正确",
      code:"",
      captcha:"",
      login_password:"",
      user_name:""
    };
  },
  //监听属性 类似于data概念
  computed: {
    phonechange(){
      return /^1[3|5|6|8][0-9]{9}$/.test(this.phone);
    }
  },
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
      toactive(index){
          this.activeId = index
      },
      iconpaw(){
          this.iconshow = !this.iconshow
      },
      capcthaImg(){
        this.$refs.captcha.src = "http://192.168.1.14:3000/adminapi/getcaptcha?t=" + new Date().getTime()
      },
      //获取短信验证码
     async getchpatchacode(){
          if(this.phonechange){
            let params = {
              phone:this.phone,
              // captcha:this.captcha
            }
            this.textcode = "重新获取验证码";
            this.num = 59
            this.timer = setInterval(()=>{
              this.num --;
              if(this.num == 0){
                clearInterval(this.timer)
              }
            },1000)
            let result = await getphonecode("/getcode",params,"post")
            console.log(result);
          }else{
            if(this.phone == ""){
              this.mes = "手机号不能为空"
            }
            Toast({
              message: this.mes,
              position: 'middle',
              duration: 2000
            });
          }
      },
      //短信验证码登录
     async captchalogin(){
        var params = {
          phone:this.phone,
          code:this.code,
          captcha:this.captcha
        };
        let result = await getphonecodelogin("/phonelogin",params,"post")
        // console.log(result);
        if(this.captcha == ""){
          Toast({
              message: "验证码不能为空",
              position: 'middle',
              duration: 2000
            });
       }else if(result.status == 4007){
           Toast({
              message: result.msg,
              position: 'middle',
              duration: 2000
            });
        }else if(result.status == 4005){
           Toast({
              message: result.msg,
              position: 'middle',
              duration: 2000
            });
        }
       if(result.status == 200){
          this.$router.push("/home")
       }
      },
      //用户名登录
      async getloginName(){
        let params = {
          user_name:this.user_name,
          login_password:this.login_password,
           captcha:this.captcha
        }
        let result = await getuserNamelogin("/login",params,"post")
        this.$store.dispatch("acthlogin",result)
        // console.log(result);
        if(this.captcha == ""){
          Toast({
              message: "验证码不能为空",
              position: 'middle',
              duration: 2000
            });
       }else if(result.status == 4007){
           Toast({
              message: result.msg,
              position: 'middle',
              duration: 2000
            });
        }else if(this.user_name == ""){
          Toast({
              message: "用户名不能为空",
              position: 'middle',
              duration: 2000
            });
        }else if(result.status == 1005){
              Toast({
              message: result.msg,
              position: 'middle',
              duration: 2000
            });
        }else if(this.login_password == ""){
              Toast({
              message: "密码不能为空",
              position: 'middle',
              duration: 2000
            });
        }else if(result.status == 500){
              Toast({
              message: result.msg,
              position: 'middle',
              duration: 2000
            });
        }
        if(result.status == 200){
          this.$router.push("/home")
       }
      }
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {
      this.activeId = this.$route.query.id
  },
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.login {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  background-color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  .back{
    position: relative;
    span{
      position: absolute;
      top: -13rem;
      left: -17rem;
      font-size: 1.8rem;
      color: #bdbdbd;
    }
  }
  .lgoin_img {
    width: 100%;
    height: 10rem;
    // border-radius: 50%;
    // border: 1px solid #efefef;
    display: flex;
    justify-content: center;
    align-items: center;
    box-sizing: border-box;
    margin: -5rem 0 2rem;
    // img {
    //   width: 8rem;
    //   height: 8rem;
    //   margin-top: 1.5rem;
    // }
    h3{
    width: 100%;
    text-indent: 1.5rem;
    font-size: 4rem;
    font-weight: 300;
    }
  }
  .tologin_tabs {
    width: 100%;
    width: calc(100% - 2rem);
    margin-left: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .btn {
      width: 50%;
      height: 4.4rem;
      line-height: 4.4rem;
      text-align: center;
      font-size: 1.4rem;
      background-color: #efefef;
      margin-bottom: 1rem;
    }
    .active {
      background-color: #f44;
      color: #fff;
    }
  }
  .to_item {
    width: 100%;
    width: calc(100% - 2rem);
    margin-left: 1rem;
    .item_content {
      width: 100%;
      .item_input {
          width: 100%;
        height: 4rem;
        line-height: 4rem;
        margin-bottom: 1rem;
        position: relative;
        display: flex;
        color: #bdbdbd;
        i{
            display: inline-block;
            position: absolute;
            width: 3rem;
            height: 4rem;
            line-height: 4rem;
            text-align: center;
            font-size: 1.6rem;
        }
        input {
          width: 75%;
          height: 4rem;
          border: 1px solid #efefef;
          box-sizing: border-box;
          text-indent: 3rem;
          &::-webkit-input-placeholder {
            color: #999;
            }
        }
        button {
          width: 38%;
          height: 4rem;
          line-height: 4rem;
        }
        img{
          width: 12rem;
          height: 4rem;
        }
      }
      .tabs_input{
          position: relative;
          .icon-yincang,.icon-xianshi{
              display: inline-block;
              width: 2rem;
              height: 4rem;
              text-align: center;
              line-height: 4rem;
              position: absolute;
              font-size: 1.6rem;
              right: 1rem;
          }
      }
      .reglog{
          width: 100%;
          height: 4rem;
          background-color: #f44;
          color: #fff;
          line-height: 4rem;
          text-align: center;
          font-size: 1.4rem;
          border-radius: 1rem;
      }
    }
  }
  .register{
      height: 4rem;
      line-height: 4rem;
      a{
          height: 4rem;
         color: #f44;
         text-decoration: underline;
      }
  }
}
</style>