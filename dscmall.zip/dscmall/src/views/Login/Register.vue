<!--  -->
<template>
  <div class="Register">
    <div class="back">
      <span class="iconfont icon-jiantou3" @click="back"></span>
    </div>
    <h2>用户注册</h2>
    <div class="reg">
      <input type="text" v-model="user_name" placeholder="用户名" />
      <i class="iconfont icon-wode"></i>
    </div>
    <div class="reg resu">
      <i class="iconfont icon-icon-pwd"></i>
      <input
        type="password"
        v-model="login_password"
        v-if="show"
        placeholder="密码"
      />
      <span class="iconfont icon-yincang" @click="shows" v-if="show"></span>
      <input
        type="text"
        v-model="login_password"
        v-if="!show"
        placeholder="密码"
      />
      <span class="iconfont icon-xianshi" @click="shows" v-if="!show"></span>
    </div>
    <div class="reg">
      <input type="text" v-model="phone" placeholder="手机号" />
      <i class="iconfont icon-tubiao--copy"></i>
    </div>
    <div class="reglog" @click="register">注册</div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { getuserRegister } from "@/api/api";
import { MessageBox, Toast } from "mint-ui";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  data() {
    //这里存放数据
    return {
      user_name: "",
      login_password: "",
      phone: "",
      show: true,
    };
  },
  //监听属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    back() {
      this.$router.push("/mine");
    },
    shows() {
      this.show = !this.show;
    },
    async register() {
      let param = {
        user_name: this.user_name,
        login_password: this.login_password,
        phone: this.phone,
      };
      const result = await getuserRegister("/register", param, "post");
      if (this.user_name == "") {
        Toast({
          message: "用户名不能为空",
          position: "middle",
          duration: 2000,
        });
      } else if (result.status == 5001) {
        Toast({
          message: result.msg,
          position: "middle",
          duration: 2000,
        });
      } else if (this.login_password == "") {
        Toast({
          message: "密码不能为空",
          position: "middle",
          duration: 2000,
        });
      } else if (this.phone == "") {
        Toast({
          message: "手机号不能为空",
          position: "middle",
          duration: 2000,
        });
      } else if (result.status == 5000) {
        Toast({
          message: result.msg,
          position: "middle",
          duration: 2000,
        });
      }

      if (result.status == 200) {
        MessageBox.confirm("您已注册成功了，快去登陆吧").then(
          () => {
            this.$router.push("/mine");
          },
          () => {}
        );
      }
    },
  },
  beforeCreate() {}, //生命周期 - 创建之前
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  beforeMount() {}, //生命周期 - 挂载之前
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style scoped lang="less">
.Register {
  width: 100%;
  height: 100vh;
  background-color: #fff;
  position: fixed;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  box-sizing: border-box;
  .back {
    position: absolute;
    top: 3rem;
    left: 2rem;
    font-size: 1.6rem;
  }
  h2 {
    width: 100%;
    margin-bottom: 5rem;
    font-weight: 400;
    font-size: 4rem;
    text-indent: 2rem;
  }
  .reg {
    width: 100%;
    width: calc(100% - 4rem);
    margin-left: 0.8rem;
    position: relative;
    i {
      position: absolute;
      left: 1rem;
      top: 1.5rem;
      font-size: 1.6rem;
    }
    input {
      width: 100%;
      height: 4.4rem;
      border: 1px solid #efefef;
      margin-bottom: 3rem;
      text-indent: 3rem;
    }
  }
  .resu {
    display: flex;
    position: relative;
    span {
      position: absolute;
      right: 1rem;
      font-size: 1.4rem;
      top: 1.5rem;
    }
  }
  .reglog {
    width: 100%;
    height: 4.4rem;
    width: calc(100% - 4rem);
    margin-left: 1.3rem;
    background-color: #f44;
    color: #fff;
    text-align: center;
    line-height: 4.4rem;
    font-size: 1.4rem;
    border-radius: 0.6rem;
    margin-top: 2rem;
  }
}
</style>