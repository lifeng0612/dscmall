<!--  -->
<template>
  <div class="search">
    <div class="searah_header">
      <section>
        <form action="">
          <div class="seach-wrap">
            <div class="back">
              <a
                href="javascript:;"
                class="iconfont icon-jiantou3"
                onclick="window.history.back()"
              ></a>
            </div>
            <div class="input">
              <input
                type="text"
                placeholder="搜索商品"
                v-model="keywords"
                @input="inputkey"
                @blur="inputclose"
                ref="inputs"
              />
              <i
                class="iconfont icon-chahao"
                style="right: 3rem; color: red; font-weight: 700"
                v-if="clearshow"
                @click="clearkey"
              ></i>
              <i class="iconfont icon-sousuo2"></i>
            </div>
            <div class="back">
              <a href="javascript:;" @click="searchkeyword">搜索</a>
            </div>
          </div>
        </form>
      </section>
    </div>
    <div class="lately_search">
      <div class="lately_top">
        <span>最近搜索</span>
        <i class="iconfont icon-shanchu" @click="clearkeyword"></i>
      </div>
      <ul>
        <li v-if="!searchkeywords.length > 0">暂无</li>
        <li v-for="(searchkeyword, index) in searchkeywords" :key="index">
          <router-link :to="'/searchlist?keywords=' + searchkeyword">
            {{ searchkeyword }}
          </router-link>
        </li>
      </ul>
    </div>
    <div class="lately_search hot_search">
      <div class="lately_top">
        <span>热门搜索</span>
      </div>
      <ul>
        <li
          v-for="(hot, index) in hotdata"
          :key="index"
          @click="hotkeywords(index)"
        >
          <router-link :to="'/searchlist?keywords=' + hot">
            {{ hot }}
          </router-link>
        </li>
      </ul>
    </div>
    <QuickNavigation></QuickNavigation>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import QuickNavigation from "@/components/QuickNavigation";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    QuickNavigation,
  },
  data() {
    //这里存放数据
    return {
      keywords: "",
      hotdata: ["T恤", "Five Plus", "手机"],
      clearshow: false,
    };
  },
  //监听属性 类似于data概念
  computed: {
    searchkeywords() {
      return this.$store.state.searchkeywords;
    },
  },
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    searchkeyword() {
      let inputs = this.$refs.inputs.placeholder;
      if (inputs == this.searchkeywords[0]) {
        this.$router.push("/searchlist?keywords=" + inputs);
      }
      if (this.keywords) {
        this.$store.commit("searchkeyword", this.keywords);
        this.$router.push("/searchlist?keywords=" + this.keywords);
      }
    },
    hotkeywords(index) {
      this.$store.commit("hotkeywords", this.hotdata[index]);
    },
    clearkeyword() {
      this.$store.commit("clearkeyword");
      this.$refs.inputs.placeholder = "搜索商品";
    },
    inputkey() {
      this.clearshow = true;
    },
    inputclose() {},
    clearkey() {
      this.keywords = "";
      this.clearshow = false;
      this.$refs.inputs.focus();
    },
  },
  mounted() {
    if (this.searchkeywords.length > 0) {
      this.$refs.inputs.placeholder = this.searchkeywords[0];
    }
    this.$nextTick(() => {
      this.$refs.inputs.focus();
    });
  },
};
</script>
<style lang="less">
.search {
  width: 100%;
  box-sizing: border-box;
  background-color: #fff;
  .searah_header {
    width: 100%;
    height: 5rem;
    box-sizing: border-box;
    position: fixed;
    top: 0;
    left: 0;
    border-bottom: 1px solid #efefef;
    background-color: #fff;
    padding: 0.8rem 0;
    section {
      width: 100%;
      height: 100%;
      form {
        width: 100%;
        height: 100%;
        .seach-wrap {
          width: 100%;
          height: 100%;
          display: flex;
          .back {
            width: 10%;
            text-align: center;
            a {
              width: 100%;
              height: 100%;
              padding-left: 0.3rem;
              line-height: 3.3rem;
              font-size: 1.4rem;
            }
            .icon-jiantou3 {
              display: inline-block;
              text-align: center;
              font-size: 1.6rem;
            }
          }
          .input {
            width: 78%;
            display: flex;
            position: relative;
            input {
              border: 1px solid #ccc;
              border-radius: 50px;
              width: 100%;
              height: 100%;
              text-indent: 1.5rem;
            }
            i {
              width: 3rem;
              height: 100%;
              position: absolute;
              top: 0;
              right: 0.6rem;
              display: flex;
              justify-content: center;
              align-items: center;
              color: #888;
              font-size: 1.6rem;
            }
          }
        }
      }
    }
  }
  .lately_search {
    width: 100%;
    width: calc(100% - 2rem);
    background-color: #fff;
    margin: 5rem 1rem 0;
    .lately_top {
      padding: 1rem 0;
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      span {
        font-size: 1.6rem;
      }
      i {
        font-size: 1.4rem;
      }
    }
    ul {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      li {
        height: 3rem;
        line-height: 3rem;
        text-align: center;
        background-color: #f0f2f5;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
        margin-left: 6%;
        padding: 0 1rem;
        color: #686868;
      }
    }
  }
  .hot_search {
    margin-top: 0;
  }
}
</style>