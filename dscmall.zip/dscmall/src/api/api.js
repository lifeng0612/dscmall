import ajax from "@/api/ajax"

const base_url = "/api"
const base_url2 = "http://192.168.1.14:3000/adminapi"
    //首页列表
export const getHomeList = (url, params) => {
    return ajax(base_url + url, params)
};
//首页拼团专区
export const getSpellList = () => {
    return ajax(base_url + "/visual/visual_team_goods")
};
//首页秒杀
export const getSeckill = (url, params) => {
    return ajax(base_url + url, params)
};
//首页家用电器 及后面列表内容
export const getHome = (params) => {
    return ajax(base_url + "/visual/visual_second_category", params)
};

//分类列表
export const getClassifyList = () => {
    return ajax(base_url + "/catalog/list")
};
//分类详情
export const getpages = (url) => {
    return ajax(base_url + url)
};
//分类列表详情
export const getcates = (url, params, type) => {
    return ajax(base_url + url, params, type)
};
// 详情页
export const getdetail = (url, params, type) => {
    return ajax(base_url + url, params, type)
};
// 详情页列表
export const getdetailList = (url, params, type) => {
    return ajax(base_url + url, params, type)
};
// 家用电器 ....
export const gethomeotherList = (url, params, type) => {
    return ajax(base_url + url, params, type)
};

// 短信验证码
export const getphonecode = (url, params, type) => {
    return ajax(base_url2 + url, params, type)
};

// 短信验证码登录
export const getphonecodelogin = (url, params, type) => {
    return ajax(base_url2 + url, params, type)
};

//用户名登录
export const getuserNamelogin = (url, params, type) => {
    return ajax(base_url2 + url, params, type)
};
//用户注册
export const getuserRegister = (url, params, type) => {
    return ajax(base_url2 + url, params, type)
};