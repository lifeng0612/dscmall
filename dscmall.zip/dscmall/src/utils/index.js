export function isweixin() {
    return navigator.userAgent.toLowerCase().indexOf('micromessenger') != -1
}