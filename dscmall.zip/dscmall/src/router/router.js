import Vue from "vue"
import VueRouter from "vue-router"
//使用
Vue.use(VueRouter)

//解决刷新报错
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
}

//创建组件
import Home from "../views/Home/Home.vue"
import Category from "../views/Category/Category.vue"
import Find from "../views/Find/Find.vue"
import Cart from "../views/Cart/Cart.vue"
import Mine from "../views/Mine/Mine.vue"
import Empty from "@/components/Empty"

//配置路由
let routes = [{
    path: "/",
    redirect: "/home/index"
}, {
    path: "/home",
    component: Home,
    children: [{
        path: "index", //首页
        component: () =>
            import ('../views/Home/children/Index.vue') //按需引入
    }, {
        path: "household", //家用电器
        component: () =>
            import ('../views/Home/children/Household.vue') //按需引入
    }, {
        path: "clothing", //男装女装
        component: () =>
            import ('../views/Home/children/Clothing.vue') //按需引入
    }, {
        path: "shoebag", //鞋靴箱包
        component: () =>
            import ('../views/Home/children/ShoeBag.vue') //按需引入
    }, {
        path: "mobilephones", //手机数码
        component: () =>
            import ('../views/Home/children/MobilePhones.vue') //按需引入
    }, {
        path: "computer", //电脑办公
        component: () =>
            import ('../views/Home/children/Computer.vue') //按需引入
    }, {
        path: "hometextiles", //家居家纺
        component: () =>
            import ('../views/Home/children/HomeTextiles.vue') //按需引入
    }, {
        path: "personalmakeup", //个人化妆
        component: () =>
            import ('../views/Home/children/PersonalMakeup.vue') //按需引入
    }, {
        path: "/home",
        redirect: "/home/index"
    }]
}, {
    path: "/category",
    component: Category
}, {
    path: "/find",
    component: Find
}, {
    path: "/cart",
    component: Cart
}, {
    path: "/mine",
    component: Mine
}, {
    path: "/empty",
    component: Empty
}, {
    path: "/search",
    component: () =>
        import ('../views/search/Search.vue')
}, {
    path: "/categorylists/:cid",
    component: () =>
        import ('../views/Category/components/Categorylists.vue')
}, {
    path: "/goodsdetail/:gid",
    component: () =>
        import ('../views/Detail/Detail.vue')
}, {
    path: "/searchlist",
    component: () =>
        import ('../views/search/SearchList.vue')
}, {
    path: "/login",
    component: () =>
        import ('../views/Login/Login.vue')
}, {
    path: "/register",
    component: () =>
        import ('../views/Login/Register.vue')
}]

//创建路由对象
let router = new VueRouter({
    routes
});
router.beforeEach((to, from, next) => {
    // console.log(from);
    if (to.path == "/mine" || to.path == "/login" || to.path == "/register" || to.path == "/home/index") {
        next()
        return;
    } else if (!window.localStorage.getItem("userInfo")) {
        next("/mine")
    }
    if (window.localStorage.getItem("userInfo")) {
        var token = JSON.parse(window.localStorage.getItem("userInfo")).token
    }
    if (!token) return next("/mine")
    next()
});
//暴露
export default router