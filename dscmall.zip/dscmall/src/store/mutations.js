import { MessageBox } from 'mint-ui';
const mutations = {

    changedetail(state, data) {
        state.detaildate = data
    },
    changedetailbasic(state, data) {
        state.detaildatebasic = data
    },
    changeloading(state, data) {
        state.loading = data
    },
    changedetaillist(state, data) {
        state.detailLists = state.detailLists.concat(data)
    },
    changePosterData(state, data) {
        state.posterDatas = data
    },
    changeotherdata(state, data) {
        state.homelistdata = state.homelistdata.concat(data)
    },
    setCartDatas(state, data) {
        if (data) {
            state.cartDatas.push(data)
        }
        localStorage.setItem("carts", JSON.stringify(state.cartDatas))
    },
    //商品按钮
    select(state, data) {
        let radionum = state.cartDatas.every(item => {
            return item.isSelect == true
        })
        state.selectAll = radionum
        state.cartDatas[data.index] = data.cart
        localStorage.setItem("carts", JSON.stringify(state.cartDatas))
        localStorage.setItem("selectAll", state.selectAll)
    },
    //全选按钮
    changeselectAll(state) {
        state.selectAll = !state.selectAll
        state.cartDatas.forEach(item => {
            item.isSelect = state.selectAll
        })
        localStorage.setItem("carts", JSON.stringify(state.cartDatas))
        localStorage.setItem("selectAll", state.selectAll)
    },
    //商品++
    addcart(state, index) {
        state.cartDatas[index].valus++;
        localStorage.setItem("carts", JSON.stringify(state.cartDatas))
    },
    //商品--
    reducecart(state, index) {
        if (state.cartDatas[index].valus == 1) {
            state.cartDatas[index].valus = 1
        } else {
            state.cartDatas[index].valus--;
            localStorage.setItem("carts", JSON.stringify(state.cartDatas))
        }
    },
    //删除
    clearcart(state, index) {
        MessageBox.confirm('亲！您确定删除该商品吗?').then(() => {
            state.cartDatas.splice(index, 1);
            localStorage.setItem("carts", JSON.stringify(state.cartDatas))
        }, () => {});
    },
    //搜索
    searchkeyword(state, data) {
        if (data) {
            for (var key in state.searchkeywords) {
                if (data == state.searchkeywords[key]) {
                    state.searchkeywords.splice(key, 1);
                }
            }
        }
        state.searchkeywords.unshift(data)
        localStorage.setItem("keywords", JSON.stringify(state.searchkeywords))
    },
    // 热门搜索
    hotkeywords(state, data) {
        console.log(data);
        if (data) {
            for (var key in state.searchkeywords) {
                if (data == state.searchkeywords[key]) {
                    state.searchkeywords.splice(key, 1);
                }
            }
        }
        state.searchkeywords.unshift(data)
        localStorage.setItem("keywords", JSON.stringify(state.searchkeywords))
    },
    //清除搜索缓存
    clearkeyword(state) {
        state.searchkeywords = []
        localStorage.setItem("keywords", JSON.stringify(state.searchkeywords))
    },
    //登录
    userInfodata(state, data) {
        state.userInfo = data
        localStorage.setItem("userInfo", JSON.stringify(state.userInfo))
    },
    extclear(state) {
        // console.log(JSON.stringify(state.userInfo));
        MessageBox.confirm('亲！您确定退出登陆吗?').then(() => {
            window.localStorage.removeItem("userInfo")
            window.location.reload()
        }, () => {});
    },

}


export default mutations