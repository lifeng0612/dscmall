const state = {
    detaildate: {},
    detaildatebasic: {},
    loading: false,
    detailLists: [],
    posterDatas: {},
    homelistdata: [],
    cartDatas: localStorage["carts"] ? JSON.parse(localStorage["carts"]) : [],
    selectAll: localStorage["selectAll"] ? JSON.parse(localStorage["selectAll"]) : false,
    searchkeywords: localStorage["keywords"] ? JSON.parse(localStorage["keywords"]) : [],
    //存储登陆成功后的数据
    userInfo: localStorage["userInfo"] ? JSON.parse(localStorage["userInfo"]) : {}
}


export default state