import { getdetail, getdetailList, gethomeotherList } from "@/api/api.js"
import QRCode from "qrcode"
const actions = {
    async actChangedetail(context, params) {
        context.commit("changeloading", false)
        let resultdetail = await getdetail(params.url, params.params, params.type)
            // console.log(resultdetail);

        let img = resultdetail.data.gallery_list[0].img_url

        function getBase64(img) {
            var canvas = document.createElement("canvas")
            var ctx = canvas.getContext("2d")
            canvas.width = img.width
            canvas.height = img.height
            img.crossOrigin = "Anonymous"
            ctx.drawImage(img, 0, 0, img.width, img.height);
            var ext = img.src.substring(img.src.lastIndexOf(".") + 1).toLowerCase()
            var dataUrl = canvas.toDataURL("image/" + ext)
            return dataUrl
        }

        var image = new Image()
        image.src = img
        let goodsUrl = location.href //获取当前页面的url
        var code = await QRCode.toDataURL(goodsUrl)
        image.onload = function() {
            let base64 = getBase64(image)
            let posterDatas = {
                image: base64,
                title: resultdetail.data.goods_name,
                price: resultdetail.data.shop_price,
                dprice: resultdetail.data.market_price,
                code: code,
            }
            context.commit("changePosterData", posterDatas)
        }
        if (resultdetail.status == "success") {
            context.commit("changedetail", resultdetail.data)
            context.commit("changedetailbasic", resultdetail.data.basic_info)
            context.commit("changeloading", true)
        }
    },
    async actChangedetailList(context, params) {
        context.commit("changeloading", false)
        let resultdetaillist = await getdetailList(params.url, params.params, params.type)
            // console.log(resultdetaillist.data);
        context.commit("changedetaillist", resultdetaillist.data)
        context.commit("changeloading", true)
    },
    //Homeother
    async acthangeotherlist(context, params) {
        let reshomelist = await gethomeotherList(params.url, params.params, params.type)
            // console.log(reshomelist.data);
        context.commit("changeotherdata", reshomelist.data)
    },
    //登录
    async acthlogin(context, data) {
        context.commit("userInfodata", data)
    }
}

export default actions