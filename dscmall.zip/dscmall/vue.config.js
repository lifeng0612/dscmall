//配置vue项目--修改完配置文件需要从新启动项目才能生效
module.exports = {
    publicPath: "./",
    devServer: {
        host: "0.0.0.0",
        port: "9527",
        open: true,
        proxy: { //配置跨域请求
            "/api": {
                target: "https://x.dscmall.cn/api", //配置要代理的域名
                // target: "https://demo.dscmall.cn/api",
                changeOrigin: true, //允许跨域
                pathRewrite: { //路径重写
                    "^/api": ""
                }
            }
        }
    }
}